# Reviewed source kit

Install dependencies with npm install. Render a registered composition using npx remotion render <composition-id> output.mp4. Covers use npx remotion still src/cover-root.tsx cover cover.jpg with topic props. Node.js, Chromium runtime and FFmpeg are external dependencies. System font availability can change text metrics; clean-machine exact reproduction has not been tested. The included source and assets correspond to the reviewed final batch versions.
