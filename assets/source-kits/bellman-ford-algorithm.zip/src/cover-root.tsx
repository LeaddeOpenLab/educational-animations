import React from 'react';
import {AbsoluteFill,Composition,registerRoot} from 'remotion';
import {Cover,COVER_FIGURES} from './components/Cover';
const Audit:React.FC<{figure?:string}>=({figure})=>{const F=figure?COVER_FIGURES[figure]:undefined;return <AbsoluteFill style={{backgroundColor:'#000'}}><div style={{position:'absolute',left:180,top:140,width:640,height:620}}>{F?<F/>:null}</div></AbsoluteFill>};
const Root:React.FC=()=> <><Composition id="cover" component={Cover} width={1920} height={1080} fps={30} durationInFrames={1} defaultProps={{name:'Concept',brand:'icon' as const}}/><Composition id="cover-audit" component={Audit} width={1000} height={900} fps={30} durationInFrames={1} defaultProps={{figure:''}}/></>;
registerRoot(Root);
