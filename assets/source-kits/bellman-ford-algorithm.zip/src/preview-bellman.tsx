import React from 'react';import {Composition,registerRoot} from 'remotion';import {makeVideo,totalFrames} from './Video';import {SCENES} from './videos/al14-bellman-ford-algorithm';
registerRoot(()=> <Composition id="bellman-preview" component={makeVideo(SCENES)} durationInFrames={totalFrames(SCENES)} fps={30} width={1920} height={1080}/>);
