import React from 'react';
import {GraphView} from './Algo';
import {COLORS,FONT} from '../theme';
export const BellmanCover:React.FC=()=> <svg width={640} height={620} viewBox="0 0 640 620" style={{fontFamily:FONT}}>
 <text x={320} y={85} textAnchor="middle" fontSize={28} fontWeight={700} fill={COLORS.accent}>RELAX A NEGATIVE EDGE</text>
 <g transform="translate(0 80)"><GraphView width={640} height={420} nodes={[{id:'S',x:.08,y:.5},{id:'A',x:.82,y:.05},{id:'B',x:.82,y:.95}]} edges={[{u:'S',v:'A'},{u:'S',v:'B'},{u:'A',v:'B'}]} directed progress={1} nodeState={{S:'visited',A:'visited',B:'current'}} edgeState={{'S->A':'tree','A->B':'active'}} dist={{S:0,A:4,B:2}} r={33}/><text x={295} y={130} fill={COLORS.textStrong} fontSize={26}>4</text><text x={290} y={285} fill={COLORS.textStrong} fontSize={26}>7</text><text x={435} y={216} fill={COLORS.accent} fontSize={27}>−2</text></g>
 <text x={320} y={544} textAnchor="middle" fill={COLORS.result} fontSize={30}>4 + (−2) = 2 &lt; 7</text>
</svg>;
