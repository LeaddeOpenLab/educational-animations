import type { SceneDef } from '../Video';
import { SCENES as v0 } from './al14-bellman-ford-algorithm';
export const VIDEOS = [
{id:"al14-bellman-ford-algorithm",title:"Bellman-Ford Algorithm",file:"al14_Bellman-Ford_Algorithm",scenes:v0,keyFrames:[110, 270, 510, 680, 835, 935]},
];