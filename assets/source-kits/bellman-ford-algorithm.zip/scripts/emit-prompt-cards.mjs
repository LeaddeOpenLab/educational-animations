#!/usr/bin/env node
/**
 * Emit one reusable English prompt card per rendered video.
 *
 *   node scripts/emit-prompt-cards.mjs <projectDir> <outDir>
 *
 * Why an emitter instead of hand-written cards: the card is matched to its video
 * by the SCENES ids in `beats`, and the frame total is read from the source, so a
 * card can never describe a video that does not exist or a runtime that is wrong.
 * `beats` is the identity check — its copy/figure text is no longer emitted.
 * Authored content lives in scripts/prompt-cards.data.mjs.
 *
 * Layout it expects in <projectDir>:
 *   src/videos/al*.tsx         each exporting `SCENES = [{ id, Comp, dur }, ...]`
 *   assets/palettes.json       this course pack, for the colour block
 *
 * Fails loudly (non-zero exit) if a card's beats do not line up with the code,
 * or if a video's scene frame total is not positive.
 */

import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CARDS, COURSE } from './prompt-cards.data.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const LIB = JSON.parse(readFileSync(join(HERE, '..', 'assets', 'palettes.json'), 'utf8'));

const [projectArg, outArg] = process.argv.slice(2);
if (!projectArg || !outArg) {
  console.error('usage: node scripts/emit-prompt-cards.mjs <projectDir> <outDir>');
  process.exit(2);
}
const project = resolve(projectArg);
const outDir = resolve(outArg);
const videosDir = join(project, 'src', 'videos');

const FPS = 30;
// Duration follows the actual scene timeline, not a fixed slot.

/** ---------------- read the real scene budgets out of the source ---------------- */

function parseScenes(file) {
  const src = readFileSync(file, 'utf8');

  // Scene durations are written as named constants (`const D1 = 110;` then
  // `dur: D1`), so resolve the numeric consts in this file first.
  const consts = {};
  for (const m of src.matchAll(/const\s+([A-Za-z_$][\w$]*)\s*=\s*(\d+)\s*;/g)) {
    consts[m[1]] = Number(m[2]);
  }
  const resolveDur = (tok) => (/^\d+$/.test(tok) ? Number(tok) : consts[tok]);

  const m = src.match(/export const SCENES[^=]*=\s*\[([\s\S]*?)\n\];/);
  if (!m) return null;
  const entry = /\{\s*id:\s*'([^']+)'\s*,\s*Comp:\s*[A-Za-z0-9_$]+,\s*dur:\s*([A-Za-z0-9_$]+)\s*\}/g;
  const out = [];
  let e;
  while ((e = entry.exec(m[1]))) {
    const dur = resolveDur(e[2]);
    if (!Number.isFinite(dur)) {
      console.error(`  ${file}: cannot resolve dur "${e[2]}" for scene "${e[1]}"`);
      return null;
    }
    out.push({ id: e[1], dur });
  }
  return out.length ? out : null;
}

const videoFiles = readdirSync(videosDir)
  .filter((f) => /^al\d+.*\.tsx$/.test(f))
  .sort()
  .map((f) => join(videosDir, f));

const parsed = [];
for (const f of videoFiles) {
  const scenes = parseScenes(f);
  if (scenes) parsed.push({ file: f, scenes });
}

if (!parsed.length) {
  console.error(`no SCENES arrays found under ${videosDir}`);
  process.exit(1);
}

/** ---------------- helpers ---------------- */

const pad = (n, w = 2) => String(n).padStart(w, '0');

/**
 * Motion style, condensed to the verb vocabulary.
 *
 * The authored `motion` entries are full sentences because they are written
 * element by element. A card only needs the *style*, so we pull the verbs out
 * and drop the prose — `card.motionStyle` overrides when the data wants to say
 * something the verb list cannot.
 */
const MOTION_VERBS = [
  'draw-on',
  'flip-and-slide',
  'stagger-in',
  'slide-up',
  'pop-in',
  'stem-reveal',
  'band-sweep',
  'marker-travel',
  'count-up',
];

function motionClause(card) {
  const text = (card.motion ?? []).join(' ');
  const found = MOTION_VERBS.filter((v) => text.includes(v));
  const style = card.motionStyle ?? (found.length ? found.join(' + ') : 'staggered fade-in with draw-on paths');
  return `${style} — each element fades in over 12f with offsets stepping 8-14f, and nothing lands in a scene's last 25 frames`;
}

function paletteSentence(paletteId) {
  const p = LIB.palettes.find((x) => x.id === paletteId);
  if (!p) {
    console.error(`palette "${paletteId}" not in assets/palettes.json`);
    process.exit(1);
  }
  const c = p.colors;
  const ground = p.mode === 'dark' ? 'Dark ground' : 'Light ground';
  const parts = [
    `${ground} \`${c.bg0}\` -> \`${c.bg1}\` -> \`${c.bg2}\``,
    `primary \`${c.primary}\` on the main structure`,
    `accent \`${c.accent}\` on the one live quantity`,
    `result \`${c.result}\` on the settled answer`,
    `warn \`${c.warn}\` on the discarded branch`,
    `${p.font} throughout, 700-800 headings, 21px uppercase kickers at 5px letter-spacing`,
  ];
  if (p.roleOverrides) {
    const over = Object.entries(p.roleOverrides)
      .map(([role, meaning]) => `${role} means "${meaning}"`)
      .join(', ');
    parts.push(`ROLE OVERRIDE — ${over}`);
  }
  return parts.join('; ') + '.';
}

/** ---------------- emit ---------------- */

mkdirSync(outDir, { recursive: true });
const index = [];
const problems = [];

for (const card of CARDS) {
  const want = Object.keys(card.beats);
  const match = parsed.find(
    (p) => p.scenes.length === want.length && p.scenes.every((s, i) => s.id === want[i])
  );
  if (!match) {
    problems.push(
      `${card.id}: no source file whose SCENES ids are [${want.join(', ')}]. ` +
        `Available: ${parsed.map((p) => `${p.file.split('/').pop()} [${p.scenes.map((s) => s.id).join(',')}]`).join(' | ')}`
    );
    continue;
  }

  const total = match.scenes.reduce((s, x) => s + x.dur, 0);
  if (!Number.isFinite(total) || total / FPS < 25 || total / FPS > 35) {
    problems.push(`${card.id}: scene duration ${total / FPS}s is outside the default 25–35s short-video budget`);
    continue;
  }

  const paletteId = card.palette ?? 'intro-algorithms';
  const palette = LIB.palettes.find((p) => p.id === paletteId);
  if (!palette) {
    problems.push(`${card.id}: palette "${paletteId}" is not in assets/palettes.json`);
    continue;
  }

  const kp = card.knowledgePoint;
  const gist = card.task ? ` ${card.task}` : '';

  // Two sentences, on purpose.
  //
  // The earlier card carried a per-scene skeleton (frame budgets, on-screen copy,
  // figure inventory per beat), a hard-constraints block, a reuse block and a
  // duplicate cheat-sheet table — about 1.7K tokens each, and the skeleton was
  // most of it. None of that survives a hand-over: the reader gets a title they
  // did not write and copy they cannot re-word without seeing the film. What
  // does survive is the knowledge point and the visual language. Everything else
  // was volume.
  const prompt = [
    `A ${total / FPS}-second silent English concept animation for a university ${COURSE} course: ${kp}.${gist}`,
    '',
    `${paletteSentence(paletteId)} ${motionClause(card)}.`,
  ].join('\n');

  const md = [
    '---',
    `video: ${card.file}.mp4`,
    `knowledge_point: "${kp}"`,
    `palette: ${paletteId}`,
    `mode: ${palette.mode}`,
    `duration_s: ${total / FPS}`,
    `frames: ${total}`,
    '---',
    '',
    `# ${card.file.replace(/^\d+_/, '').replace(/_/g, ' ')}`,
    '',
    '```text',
    prompt,
    '```',
    '',
  ].join('\n');

  const target = join(outDir, `${card.file}.md`);
  writeFileSync(target, md);
  index.push({
    card,
    target,
    total,
    scenes: match.scenes.length,
    paletteId,
    src: match.file.split('/').pop(),
  });
}

if (problems.length) {
  console.error('FAILED:');
  for (const p of problems) console.error('  -', p);
  process.exit(1);
}

/** ---------------- index ---------------- */

const palettesUsed = [...new Set(index.map((r) => r.paletteId))];

const idx = [
  `# ${COURSE} — ${index.length} reusable prompts`,
  '',
  'Two sentences per video: what the knowledge point is, and what the palette and',
  'motion style are. That is the whole card — it is meant to be pasted into another',
  'model as-is, so it carries the exact hex values rather than a reference to them.',
  '',
  'The reference implementation column points at the scene source, which is where',
  'the per-scene frame budgets and on-screen copy live.',
  '',
  '| # | video | knowledge point | palette | scenes | frames | reference implementation |',
  '|---|---|---|---|---|---|---|',
  ...index.map((r, i) => {
    const n = pad(i + 1);
    return `| ${n} | [\`${r.card.file}.mp4\`](../${r.card.file}.mp4) · [prompt](${r.card.file}.md) | ${r.card.knowledgePoint} | \`${r.paletteId}\` | ${r.scenes} | ${r.total} | \`src/videos/${r.src}\` |`;
  }),
  '',
  `All ${index.length} share ${palettesUsed.length === 1 ? `one palette (\`${palettesUsed[0]}\`)` : `${palettesUsed.length} palettes`}`,
  `because the palette is the visual identity of the batch, not of a single video.`,
  `To re-skin the set, replace the colour sentence in every card with another palette`,
  `from \`assets/palettes.json\`; nothing else changes.`,
  '',
  `Generated by \`scripts/emit-prompt-cards.mjs\` — frame budgets are read from the`,
  `video source, so these cards cannot drift from the rendered films.`,
  '',
].join('\n');

writeFileSync(join(outDir, '00_ALL_PROMPTS.md'), idx);

console.log(`wrote ${index.length} cards + index to ${outDir}`);
for (const r of index) {
  console.log(`  ${r.card.file}.md   ${r.scenes} scenes / ${r.total}f / ${r.paletteId}`);
}
