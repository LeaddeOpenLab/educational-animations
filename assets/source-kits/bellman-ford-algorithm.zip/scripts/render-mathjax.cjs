// Prerender LaTeX -> MathJax SVG (glyphs embedded, so Remotion needs no font files).
// TEMPLATE: fill FORMULAS below for your course, then run: node scripts/render-mathjax.cjs <course-id>
//
// Single source of truth for formula colour is the course theme pack:
//   node scripts/render-mathjax.cjs                      # reads src/theme/active.json
//   node scripts/render-mathjax.cjs intro-machine-learning
//
// \textcolor bakes colour into the SVG at build time, so re-run this after any
// theme change. The baked theme name is written to src/formulas.theme.json and
// Video.tsx warns when it drifts from the active theme.
const path = require('path');
const fs = require('fs');

const themeDir = path.join(__dirname, '..', 'src', 'theme');
const activeName =
  process.argv[2] ||
  JSON.parse(fs.readFileSync(path.join(themeDir, 'active.json'), 'utf8')).theme;
const themePath = path.join(themeDir, 'themes', `${activeName}.json`);

if (!fs.existsSync(themePath)) {
  const avail = fs
    .readdirSync(path.join(themeDir, 'themes'))
    .map((f) => f.replace(/\.json$/, ''));
  console.error(`Unknown theme "${activeName}". Available: ${avail.join(', ')}`);
  process.exit(1);
}
const theme = JSON.parse(fs.readFileSync(themePath, 'utf8'));
const C = theme.colors;
console.log(`theme: ${theme.name} (${theme.label}) / mode=${theme.mode}`);

const { mathjax } = require('mathjax-full/js/mathjax.js');
const { TeX } = require('mathjax-full/js/input/tex.js');
const { SVG } = require('mathjax-full/js/output/svg.js');
const { liteAdaptor } = require('mathjax-full/js/adaptors/liteAdaptor.js');
const { RegisterHTMLHandler } = require('mathjax-full/js/handlers/html.js');
const { AllPackages } = require('mathjax-full/js/input/tex/AllPackages.js');

const P = C.primary;   // model / main entity
const A = C.accent;    // key quantity
const R = C.result;    // conclusion
const W = C.warn;      // error / danger
const T = C.alt;       // second series
const M = C.textMuted;

// ── FILL ME ─────────────────────────────────────────────────────────────────
// One entry per formula this course needs, keyed with a course-wide prefix
// (m01Title / dbRule / …). Register the keys in kit.json -> formulas.keys.
// Colours come from the theme pack (P/A/R/W/T/M above). NEVER hard-code a hex.
// 4-5 formulas per video is the observed norm.
const FORMULAS = {
  // ── al01 Divide and conquer recursion ──
  al01Title: `\\textcolor{${P}}{T(n)=a\\,T\\!\\left(\\frac{n}{b}\\right)+f(n)}`,
  al01Sub: `\\textcolor{${M}}{\\text{subproblem size }}\\frac{n}{b},\\;\\textcolor{${M}}{\\times a}`,
  al01Combine: `\\textcolor{${A}}{f(n)}\\;\\textcolor{${M}}{\\text{combine cost}}`,
  al01Base: `\\textcolor{${R}}{T(1)=\\Theta(1)}`,

  // ── al02 Recursive ──
  al02Title: `\\textcolor{${P}}{T(n)=T(n-1)+\\Theta(1)}`,
  al02Fact: `\\textcolor{${P}}{n!=n\\cdot(n-1)!}`,
  al02Tree: `\\textcolor{${M}}{\\text{recursion-tree height }}=n`,
  al02Lin: `\\textcolor{${A}}{T(n)=\\Theta(n)}`,

  // ── al03 Heap structure ──
  al03Title: `\\textcolor{${P}}{\\text{parent}(i)=\\left\\lfloor\\frac{i-1}{2}\\right\\rfloor}`,
  al03Left: `\\textcolor{${A}}{\\text{left}(i)=2i+1}`,
  al03Right: `\\textcolor{${A}}{\\text{right}(i)=2i+2}`,
  al03Prop: `\\textcolor{${R}}{A[\\text{parent}(i)]\\ge A[i]}\\;\\textcolor{${M}}{\\text{ (max-heap)}}`,

  // ── al04 Heap sort ──
  al04Title: `\\textcolor{${P}}{\\text{build-max-heap, then }\\Theta(n)\\text{ extracts}}`,
  al04Extract: `\\textcolor{${A}}{\\text{swap }A[1],A[n];\\;\\text{heap-size}{--};\\;\\text{max-heapify}(1)}`,
  al04Heapify: `\\textcolor{${M}}{\\text{max-heapify cost }}\\textcolor{${R}}{\\Theta(\\log n)}`,
  al04Complexity: `\\textcolor{${R}}{\\Theta(n\\log n)}`,

  // ── al05 Balanced binary search tree ──
  al05Title: `\\textcolor{${P}}{|h(L)-h(R)|\\le 1}\\;\\textcolor{${M}}{\\text{ (height-balanced)}}`,
  al05AVL: `\\textcolor{${A}}{\\text{balance}(x)=h(L)-h(R)}`,
  al05Rot: `\\textcolor{${M}}{\\text{single/double rotation restores balance}}`,
  al05Height: `\\textcolor{${R}}{h=\\mathcal{O}(\\log n)}`,

  // ── al06 Graph search ──
  al06Title: `\\textcolor{${P}}{\\text{BFS / DFS visit all }V\\text{ and }E}`,
  al06Queue: `\\textcolor{${A}}{\\text{BFS: FIFO queue; DFS: stack}}`,
  al06Mark: `\\textcolor{${M}}{\\text{mark discovered, skip visited}}`,
  al06Complexity: `\\textcolor{${R}}{\\mathcal{O}(V+E)}`,

  // ── al07 Shortest path ──
  al07Title: `\\textcolor{${P}}{d(v)=\\min_{(u,v)\\in E}\\{\\textcolor{${A}}{d(u)}+\\textcolor{${A}}{w(u,v)}\\}}`,
  al07Relax: `\\textcolor{${A}}{d(v)\\leftarrow\\min(d(v),\\,d(u)+w(u,v))}`,
  al07Dijkstra: `\\textcolor{${M}}{\\text{extract min }d(u)\\text{, relax its edges}}`,
  al07Correct: `\\textcolor{${R}}{d(v)=\\delta(s,v)}\\;\\textcolor{${M}}{\\text{ when extracted}}`,

  // ── al08 Dynamic programming status ──
  al08Title: `\\textcolor{${P}}{dp[i]=\\text{optimal value for subproblem }i}`,
  al08State: `\\textcolor{${A}}{\\text{state }=\\text{subproblem description}}`,
  al08Init: `\\textcolor{${M}}{\\text{base case }}\\textcolor{${R}}{dp[0]=0}`,
  al08Structure: `\\textcolor{${R}}{\\text{optimal substructure}}`,

  // ── al09 Dynamic programming transfer ──
  al09Title: `\\textcolor{${P}}{dp[i]=\\max_{j<i}\\{\\textcolor{${A}}{dp[j]}+\\textcolor{${A}}{cost(j,i)}\\}}`,
  al09Trans: `\\textcolor{${A}}{dp[i]=\\max\\{dp[i-1],\\,dp[i-2]+val_i\\}}`,
  al09Choice: `\\textcolor{${M}}{\\text{choice: include or exclude}}`,
  al09Order: `\\textcolor{${R}}{\\text{fill in increasing index order}}`,

  // ── al10 Quicksort Partitioning ──
  al10Title: `\\textcolor{${P}}{\\text{partition}(A,p,r):\\;A[p..q-1]\\le A[q]\\le A[q+1..r]}`,
  al10Pivot: `\\textcolor{${A}}{x=A[r];\\;i=p-1}`,
  al10Loop: `\\textcolor{${M}}{\\text{for }j=p..r-1:\\;\\text{if }A[j]<x\\text{ swap }A[i],A[j]}`,
  al10Cost: `\\textcolor{${R}}{\\Theta(n)}\\;\\textcolor{${M}}{\\text{ per partition}}`,

  // ── al11 Merge Step in Merge Sort ──
  al11Title: `\\textcolor{${P}}{\\text{merge}(L,R):\\;\\text{sorted interleaving of }L,R}`,
  al11Compare: `\\textcolor{${A}}{\\text{take }\\min(L[i],R[j])}`,
  al11Cost: `\\textcolor{${R}}{\\Theta(n)}\\;\\textcolor{${M}}{\\text{ to merge two }n/2\\text{ runs}}`,
  al11Inv: `\\textcolor{${M}}{\\le n-1\\text{ comparisons}}`,

  // ── al12 Union-Find Path Compression ──
  al12Title: `\\textcolor{${P}}{\\text{find}(x):\\text{ follow parent pointers to root}}`,
  al12Find: `\\textcolor{${A}}{\\text{find}(x)=\\text{find}(\\text{parent}[x])}`,
  al12Union: `\\textcolor{${M}}{\\text{union by rank: link two roots}}`,
  al12Ack: `\\textcolor{${R}}{\\mathcal{O}(\\alpha(n))}\\;\\textcolor{${M}}{\\text{ amortized (inverse Ackermann)}}`,

  // ── al13 Topological Sorting ──
  al13Title: `\\textcolor{${P}}{\\text{linear order: every edge }u\\to v\\text{ before }v}`,
  al13Kahn: `\\textcolor{${A}}{\\text{enqueue vertices with in-degree }0}`,
  al13DFS: `\\textcolor{${M}}{\\text{reverse post-order gives topo order}}`,
  al13Dag: `\\textcolor{${R}}{\\text{a DAG has a topological order}}`,
};
const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);

const tex = new TeX({ packages: AllPackages });
const svg = new SVG({ fontCache: 'local' });
const doc = mathjax.document('', { InputJax: tex, OutputJax: svg });

const results = {};
let ok = 0;
for (const [key, texCode] of Object.entries(FORMULAS)) {
  try {
    const node = doc.convert(texCode, { display: true, em: 60 });
    const html = adaptor.innerHTML(node);
    if (!html || html.length < 40) throw new Error('empty svg output');
    results[key] = { tex: texCode, svg: html, success: true };
    ok++;
  } catch (err) {
    results[key] = { tex: texCode, svg: '', success: false, error: String(err && err.message) };
    console.error('FAILED', key, err && err.message);
  }
}

const outPath = path.join(__dirname, '..', 'src', 'formulas.json');
fs.writeFileSync(outPath, JSON.stringify(results, null, 2));

fs.writeFileSync(
  path.join(__dirname, '..', 'src', 'formulas.theme.json'),
  JSON.stringify({ theme: theme.name }, null, 2) + '\n'
);

console.log(`formulas: ${ok}/${Object.keys(FORMULAS).length} -> ${outPath}`);
