#!/usr/bin/env node
/**
 * Re-lay the copy column of every al*.tsx video onto a fixed vertical ladder.
 *
 * Why: the overlap gate (R1) failed because the <Lines> block in the copy column
 * wraps to two or three visual lines and reaches down to ~y602, while the Formula
 * label and the Chip row underneath were placed at y500-720. The fix is not a
 * per-scene pixel nudge — it is to give the copy column one rhythm, the same one
 * the sibling intro-computer-science kit already passes its gate with.
 *
 * Rungs, per scene kind:
 *   title   (S1)       <Lines> lifted to top 330 and size 30 (its copy is longer),
 *                      rows stacked at 660 / 780 / 900
 *   middle  (S2..Sn-1) rows stacked at 640 / 760 / 880
 *   closing (Sn)       rows stacked at 800 / 900 / 960 — its text block is the
 *                      deepest of the film (bottom ~645), so the first rung is low
 *
 * Two things the first attempt got wrong, both fixed here:
 *
 *  1. A div written across several lines ends with `}}` and then `>` on the NEXT
 *     line, so a regex that demands `}}>` on one line silently skips every
 *     multi-line row — which is all of the `chips` rows and every row in the
 *     title and closing scenes. This version scans the whole opening tag up to
 *     its first `>` instead, so single- and multi-line rows are treated alike,
 *     and it rewrites only the `top:` value, leaving the formatting untouched.
 *
 *  2. Rungs are assigned in SOURCE order, not in current-`top` order. Current
 *     tops are what a previous partial run may already have rewritten, so they
 *     are not a stable key; source order is.
 *
 * Exception: a full-width formula parked at y850-879 is left alone. Those are
 * al04Extract / al10Loop / al12Ack, deliberately placed *below* the figure band;
 * lifting them onto a rung would drive them through the figure's x-range. Rung 3
 * is 880, which is above that window, so this test never mistakes a real rung for
 * a parked row. The test applies to middle scenes only — the title and closing
 * scenes carry no figure, so everything in them takes a rung.
 *
 * <Lines>, <Heading> and <Kicker> are React components with props and are never
 * rewritten, except for the title-scene Lines lift above.
 *
 *   node scripts/relay-copy-column.mjs <src/videos dir>           # dry run
 *   node scripts/relay-copy-column.mjs <src/videos dir> --apply    # write
 */

import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [, , dirArg, ...flags] = process.argv;
if (!dirArg) {
  console.error('usage: node scripts/relay-copy-column.mjs <src/videos dir> [--apply]');
  process.exit(2);
}
const APPLY = flags.includes('--apply');
const dir = resolve(dirArg);

const LADDER_TITLE = [660, 880, 960];
const LADDER_MIDDLE = [640, 760, 880];
const LADDER_CLOSING = [800, 900, 960];
const SHARED_ROW_TOP = 760;

const TITLE_LINES_TOP = 330;
const TITLE_LINES_SIZE = 30;
const PARKED_MIN = 850;
const PARKED_MAX = 879;

/** An opening <div …> tag, spanning lines but never crossing into the next div. */
const DIV = /<div\b((?:(?!<div\b)[\s\S]){0,600}?)>/g;
const TOP_IN = /left: 108, top: (\d+)/;

const files = readdirSync(dir)
  .filter((f) => /^al\d+.*\.tsx$/.test(f))
  .sort();

let movedRows = 0;
let liftedLines = 0;
const report = [];

for (const file of files) {
  const path = join(dir, file);
  const src = readFileSync(path, 'utf8');

  const marks = [...src.matchAll(/const S\d+:\s*React\.FC<\{ frame: number \}>/g)].map((m) => m.index);
  if (!marks.length) continue;
  const nScenes = marks.length;
  const sceneOf = (off) => {
    if (off < marks[0]) return -1; // shared, declared before S1
    let idx = 0;
    for (let i = 0; i < marks.length; i++) if (off >= marks[i]) idx = i;
    return idx;
  };

  // Copy-column rows: absolute at left 108, carrying a top.
  const rows = [];
  DIV.lastIndex = 0;
  let m;
  while ((m = DIV.exec(src))) {
    const [whole, attrs] = m;
    if (!/data-k="label"/.test(attrs)) continue;
    const t = attrs.match(TOP_IN);
    if (!t) continue;
    rows.push({ start: m.index, end: m.index + whole.length, whole, top: Number(t[1]), scene: sceneOf(m.index) });
  }
  if (!rows.length) continue;

  const moves = [];
  const notes = [];

  // Title scene: lift and tighten every <Lines> in the first scene.
  const LINES = /<Lines\b((?:(?!<Lines\b)[\s\S]){0,900}?)>/g;
  let x;
  while ((x = LINES.exec(src))) {
    if (sceneOf(x.index) !== 0) continue;
    const before = x[0];
    const after = before
      .replace(/top=\{\d+\}/, `top={${TITLE_LINES_TOP}}`)
      .replace(/size=\{\d+\}/, `size={${TITLE_LINES_SIZE}}`);
    if (after !== before) {
      moves.push({ start: x.index, end: x.index + before.length, text: after, label: `scene1 Lines -> top ${TITLE_LINES_TOP} / size ${TITLE_LINES_SIZE}` });
      liftedLines++;
    }
  }

  // Rows, grouped by scene, in source order.
  const byScene = new Map();
  for (const r of rows) {
    if (!byScene.has(r.scene)) byScene.set(r.scene, []);
    byScene.get(r.scene).push(r);
  }

  for (const [scene, list] of byScene) {
    const isTitle = scene === 0;
    const isClosing = scene === nScenes - 1 && nScenes > 1;
    const isMiddle = !isTitle && !isClosing;
    const ladder = isTitle ? LADDER_TITLE : isClosing ? LADDER_CLOSING : LADDER_MIDDLE;
    const kind = isTitle ? 'title' : isClosing ? 'closing' : 'middle';

    if (scene === -1) {
      for (const r of list) {
        if (r.top === SHARED_ROW_TOP) continue;
        moves.push({ start: r.start, end: r.end, text: r.whole.replace(`top: ${r.top}`, `top: ${SHARED_ROW_TOP}`), label: `shared row top ${r.top} -> ${SHARED_ROW_TOP}` });
        movedRows++;
      }
      continue;
    }

    const parked = isMiddle ? list.filter((r) => r.top >= PARKED_MIN && r.top <= PARKED_MAX) : [];
    const runged = list.filter((r) => !parked.includes(r));
    runged.forEach((r, i) => {
      const want = ladder[Math.min(i, ladder.length - 1)];
      if (want === r.top) return;
      moves.push({ start: r.start, end: r.end, text: r.whole.replace(`top: ${r.top}`, `top: ${want}`), label: `scene${scene + 1} (${kind}) top ${r.top} -> ${want}` });
      movedRows++;
    });
    for (const r of parked) notes.push(`scene${scene + 1} (middle) left at ${r.top} — full-width formula parked below the figure`);
  }

  moves.sort((a, b) => b.start - a.start);
  let next = src;
  for (const e of moves) next = next.slice(0, e.start) + e.text + next.slice(e.end);

  report.push({ file, moves: [...moves.map((y) => y.label), ...notes].reverse() });
  if (APPLY && next !== src) writeFileSync(path, next);
}

for (const r of report) {
  console.log(`${APPLY ? 'applied' : 'dry    '}  ${r.file}`);
  for (const d of r.moves) console.log(`          ${d}`);
}
console.log(`\n${APPLY ? 'APPLIED' : 'DRY RUN'} — ${movedRows} row(s) re-laid, ${liftedLines} title Lines lifted`);
