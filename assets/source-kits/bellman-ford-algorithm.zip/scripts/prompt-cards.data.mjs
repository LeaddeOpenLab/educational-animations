/**
 * Authored content for the per-video prompt cards — Introduction to Algorithms.
 *
 * Frame counts are NOT stored here — emit-prompt-cards.mjs reads them from
 * src/videos/*.tsx, so a card can never disagree with the code it describes.
 * `beats` is read straight out of the source too: the emitter only uses its keys
 * (the SCENES ids, in order) as the identity check between card and film.
 */

import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const VIDEOS = join(resolve(HERE, '..'), 'src', 'videos');

/** Read the SCENES ids of a video so `beats` can never drift from the film. */
const beatsOf = (id) => {
  const src = readFileSync(join(VIDEOS, `${id}.tsx`), 'utf8');
  const m = src.match(/export const SCENES[^=]*=\s*\[([\s\S]*?)\n\];/);
  if (!m) throw new Error(`no SCENES array in ${id}.tsx`);
  const ids = [...m[1].matchAll(/id:\s*'([^']+)'/g)].map((x) => x[1]);
  if (!ids.length) throw new Error(`no scene ids in ${id}.tsx`);
  return Object.fromEntries(ids.map((k) => [k, {}]));
};

export const COURSE = 'introduction to algorithms';

const card = (id, file, knowledgePoint, task, motion) => ({
  id,
  file,
  knowledgePoint,
  task,
  motion,
  palette: 'intro-algorithms',
  beats: beatsOf(id),
});

export const CARDS = [
  card(
    'al01-divide-and-conquer-recursion',
    '01_Divide_and_conquer_recursion',
    'Divide and conquer recursion is one recurrence read as a tree: a branches per level, log_b n levels deep',
    'Draw the recursion tree one level per scene, label the split and the combine cost, stop at the base case, then count every level and read the total off the tree.',
    [
      'draw-on the recursion tree one level at a time',
      'stagger-in the copy column line by line',
      'count-up the per-level work and then the total',
    ]
  ),
  card(
    'al02-recursive',
    '02_Recursive',
    'A recursive call is one frame stacked per shrink, and the height of that stack is what sets the running time',
    'Walk a call chain that shrinks by one per call, push a frame per call until the base case answers without calling, then unwind the chain and price it as a linear function of n.',
    [
      'slide-up each call frame as it is pushed',
      'stagger-in the recurrence lines',
      'count-up the returned values on the way back up',
    ]
  ),
  card(
    'al03-heap-structure',
    '03_Heap_structure',
    'A heap is an array whose indices already are a tree, so the parent-child links are arithmetic rather than pointers',
    'Draw the same seven values twice, array above and tree below, derive the index map to 2i+1 and 2i+2, then verify the max-heap property by checking every index instead of asserting it.',
    [
      'stagger-in the array cells and their tree twins in step',
      'marker-travel the index map from a parent out to both children',
      'stagger-in the property check index by index',
    ]
  ),
  card(
    'al04-heap-sort',
    '04_Heap_sort',
    'Heap sort is one idea used twice: the array is made into a max-heap in place, then the maximum is repeatedly extracted',
    'Build the heap in place, snapshot each extract-and-repair, and show the sorted tail growing at the end of the array while the live heap shrinks toward it.',
    [
      'draw-on the heap as it is built bottom up',
      'marker-travel the repair path from the new root downward',
      'slide-up each extracted value into the sorted tail',
    ]
  ),
  card(
    'al05-balanced-binary-search-tree',
    '05_Balanced_binary_search_tree',
    'The search rule alone does not bound the cost — the insertion order decides the shape, and the shape decides log n versus n',
    'Put the same five keys in two shapes, the balanced tree and the ordered-insertion list, price a search in each, then repair the bad shape with a single rotation that changes three links.',
    [
      'stagger-in the keys of both shapes',
      'marker-travel the search path down each tree',
      'flip-and-slide the rotated subtree into place',
    ]
  ),
  card(
    'al06-graph-search',
    '06_Graph_search',
    'Breadth-first and depth-first are the same algorithm with a different container, and the container decides the shape of the tree',
    'Run a real BFS and a real DFS on one graph, read the visit order and the spanning edges off each run, and contrast the tree that fans out with the one that is a single path.',
    [
      'stagger-in the graph vertices and edges',
      'marker-travel the visit order of each traversal',
      'draw-on the spanning edges as the queue or the stack yields them',
    ]
  ),
  card(
    'al07-shortest-path',
    '07_Shortest_path',
    'Shortest paths are computed by improving guesses: the smallest unsettled label is already final',
    'Watch the tentative distances fall as edges relax, justify why the smallest unsettled label can be committed, then read the final distances off a real Dijkstra run.',
    [
      'stagger-in the weighted graph',
      'count-up each tentative distance as it falls',
      'marker-travel the relax step out of a committed vertex',
    ]
  ),
  card(
    'al08-dynamic-programming-status',
    '08_Dynamic_programming_status',
    'Dynamic programming becomes possible when a subproblem can be named by a few integers, so its answer can be stored and reused',
    'Turn a coin problem into a table indexed by the amount, compute every entry out of smaller entries, and show that one base case plus one look-up does all the work.',
    [
      'stem-reveal the table row',
      'stagger-in the state column as it is named',
      'marker-travel the look-up from a state back to the smaller state it reads',
    ]
  ),
  card(
    'al09-dynamic-programming-transfer',
    '09_Dynamic_programming_transfer',
    'A transition is a state asking a question about states one step back — take this one, or leave it',
    'Draw the previous state directly above the state that reads it, run the take-or-skip choice on a real array, and show why that reading order forces the fill order and makes the last cell the answer.',
    [
      'stagger-in the value row',
      'marker-travel each transition from the current state to the state it reads',
      'count-up the table as it fills left to right',
    ]
  ),
  card(
    'al10-quicksort-partitioning',
    '10_Quicksort_Partitioning',
    'Partitioning is one sweep that leaves the array describable by a single inequality — it is not a sort',
    'Run a real Lomuto partition, name the four zones and both cursors at every step of the sweep, and show that nothing is actually in place until the final pivot swap.',
    [
      'stagger-in the array cells',
      'marker-travel the two cursors along the sweep',
      'flip-and-slide each swap as the sweep makes it',
    ]
  ),
  card(
    'al11-merge-step-in-merge-sort',
    '11_Merge_Step_in_Merge_Sort',
    'Merging cannot avoid comparing, but it can avoid comparing twice — only the two heads can be the next smallest value',
    'Draw two sorted runs with the merged output growing between them, advance one cursor per value written, and price the merge at strictly fewer than n comparisons for n values.',
    [
      'stagger-in the two runs',
      'marker-travel the head of each run',
      'count-up the comparison count and the output as it grows',
    ]
  ),
  card(
    'al12-union-find-path-compression',
    '12_Union_Find_Path_Compression',
    'Union-find is one parent pointer per element, and path compression lets a query rewire the structure it just measured',
    'Walk from a leaf up to its root, collect the nodes on the way, then re-point every one of them at the root and show that the next query from any of them is a single hop.',
    [
      'stagger-in the forest one level at a time',
      'marker-travel the find walk from the leaf up to the root',
      'draw-on each compressed pointer as it is rewired',
    ]
  ),
  card(
    'al13-topological-sorting',
    '13_Topological_Sorting',
    'A directed acyclic graph always admits an order in which every edge points forwards, and repeatedly removing a source finds one without searching',
    'Consume a real DAG source by source, print the order as vertices leave, then show that the finishing order of a depth-first search produces a valid order too.',
    [
      'stagger-in the DAG vertices and its directed edges',
      'marker-travel the removal order as each source leaves',
      'slide-up the emitted order one vertex at a time',
    ]
  ),
];
