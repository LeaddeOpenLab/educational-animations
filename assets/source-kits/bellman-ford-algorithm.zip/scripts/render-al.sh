#!/bin/zsh
# Render every Introduction to Algorithms composition at 1920x1080.
#
# Two destinations, deliberately:
#   out/final/<id>.mp4   raw render, kept for the contact sheets and the overlap gate
#   $OUT_DIR/<stem>.mp4  delivered file, re-muxed with -an so it is truly silent
#
# Remotion always muxes a silent AAC track, so the delivered file is re-muxed and
# then asserted to hold exactly one (video) stream.
set -e
cd "$(dirname "$0")/.."

OUT_DIR="${1:-$HOME/Desktop/leadde motion/Computer Science/Introduction to Algorithms}"
mkdir -p "$OUT_DIR" out/final

FFMPEG="${FFMPEG:-/Users/zhoutianshuo/.local/bin/ffmpeg}"
CONC="${CONC:-4}"
STRIP="${STRIP:-1}"

typeset -A NAMES
NAMES=(
  al01-divide-and-conquer-recursion   "01_Divide_and_conquer_recursion"
  al02-recursive                      "02_Recursive"
  al03-heap-structure                 "03_Heap_structure"
  al04-heap-sort                      "04_Heap_sort"
  al05-balanced-binary-search-tree    "05_Balanced_binary_search_tree"
  al06-graph-search                   "06_Graph_search"
  al07-shortest-path                  "07_Shortest_path"
  al08-dynamic-programming-status     "08_Dynamic_programming_status"
  al09-dynamic-programming-transfer   "09_Dynamic_programming_transfer"
  al10-quicksort-partitioning         "10_Quicksort_Partitioning"
  al11-merge-step-in-merge-sort       "11_Merge_Step_in_Merge_Sort"
  al12-union-find-path-compression    "12_Union_Find_Path_Compression"
  al13-topological-sorting            "13_Topological_Sorting"
)

ORDER=(
  al01-divide-and-conquer-recursion al02-recursive al03-heap-structure
  al04-heap-sort al05-balanced-binary-search-tree al06-graph-search
  al07-shortest-path al08-dynamic-programming-status
  al09-dynamic-programming-transfer al10-quicksort-partitioning
  al11-merge-step-in-merge-sort al12-union-find-path-compression
  al13-topological-sorting
)

for id in $ORDER; do
  name="${NAMES[$id]}"
  raw="out/final/$id.mp4"

  echo "== render $id"
  ./node_modules/.bin/remotion render "$id" "$raw" --concurrency=$CONC --log=error

  if [[ "$STRIP" == "1" ]]; then
    final="$OUT_DIR/$name.mp4"
    "$FFMPEG" -y -i "$raw" -c:v copy -an -movflags +faststart "$final" > /dev/null 2>&1
    streams=$("$FFMPEG" -i "$final" 2>&1 | grep -c "Stream #")
    dur=$("$FFMPEG" -i "$final" 2>&1 | grep "Duration" | head -1 | sed 's/.*Duration: \([0-9:.]*\).*/\1/')
    if [[ "$streams" != "1" ]]; then
      echo "!! $name has $streams streams, expected exactly 1 (video only)"
      exit 1
    fi
    echo "   $name.mp4  duration=$dur  streams=$streams"
  fi
done

echo "DONE -> out/final${STRIP:+, and $OUT_DIR}"
