import React from 'react';
import {Composition,registerRoot} from 'remotion';
import V11 from './videos/se11-role-based-access-control';
import V12 from './videos/se12-attribute-based-access-control';
import V13 from './videos/se13-saml-service-provider-login-flow';
import V14 from './videos/se14-mutual-tls-certificate-authentication';
import V15 from './videos/se15-least-privilege-access-review';
const Root=()=> <>
<Composition id="preview11" component={V11} durationInFrames={900} fps={30} width={1920} height={1080}/>
<Composition id="preview12" component={V12} durationInFrames={900} fps={30} width={1920} height={1080}/>
<Composition id="preview13" component={V13} durationInFrames={930} fps={30} width={1920} height={1080}/>
<Composition id="preview14" component={V14} durationInFrames={930} fps={30} width={1920} height={1080}/>
<Composition id="preview15" component={V15} durationInFrames={900} fps={30} width={1920} height={1080}/>
</>;registerRoot(Root);
