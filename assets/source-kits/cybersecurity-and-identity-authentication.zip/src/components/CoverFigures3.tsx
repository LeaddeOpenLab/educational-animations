import React from 'react';
import {COLORS as C,FONT,alpha} from '../theme';
import {Actor,Credential,Channel,KeyMark,CheckRow} from './Security';
const Text=({x,y,children,color=C.textStrong,size=26}:{x:number;y:number;children:React.ReactNode;color?:string;size?:number})=><text x={x} y={y} textAnchor="middle" fontSize={size} fill={color}>{children}</text>;
const Canvas=({children}:{children:React.ReactNode})=><svg width={640} height={620} viewBox="0 0 640 620" style={{fontFamily:FONT}}>{children}</svg>;
const RoleCover=()=> <Canvas>
  <Channel x1={160} y1={175} x2={325} y2={175} color={C.primary}/>
  <Channel x1={420} y1={225} x2={440} y2={330} color={C.result}/>
  <path d="M370 225L370 470H425" fill="none" stroke={C.warn} strokeWidth={3} strokeDasharray="8 8"/>
  <Actor x={95} y={155} kind="person" label="Maya"/>
  <rect x={307} y={121} width={226} height={108} rx={20} fill="none" stroke={C.accent} strokeWidth={3}/>
  <Credential x={320} y={142} w={200} title="Analyst" color={C.primary}/>
  <Text x={420} y={100} color={C.accent}>Active role</Text>
  <Credential x={385} y={342} w={200} title="Read report" color={C.result}/>
  <CheckRow x={410} y={438} label="Allowed" status="pass"/>
  <Credential x={385} y={488} w={200} title="Delete report" color={C.warn}/>
  <path d="M440 447V480" stroke={C.warn} strokeWidth={7}/>
  <Text x={215} y={525} color={C.warn}>No delete path</Text>
</Canvas>;
const AttributeCover=()=> <Canvas>
  <Channel x1={170} y1={230} x2={275} y2={330} color={C.result}/>
  <Channel x1={465} y1={230} x2={365} y2={330} color={C.warn}/>
  <Channel x1={320} y1={395} x2={320} y2={470} color={C.warn}/>
  <Credential x={50} y={155} w={235} title="Finance = Finance" color={C.result}/>
  <Credential x={355} y={155} w={235} title="Unmanaged" color={C.warn}/>
  <Text x={167} y={118}>Department</Text><Text x={472} y={118}>Device</Text>
  <CheckRow x={110} y={270} label="Match" status="pass"/><CheckRow x={410} y={270} label="Fails" status="fail"/>
  <rect x={248} y={325} width={144} height={70} rx={15} fill={alpha(C.warn,.12)} stroke={C.warn} strokeWidth={3}/><Text x={320} y={371} color={C.warn} size={32}>AND</Text>
  <Credential x={212} y={475} w={216} title="READ DENIED" color={C.warn}/>
</Canvas>;
const SamlCover=()=> <Canvas>
  <Text x={90} y={115}>Browser</Text><Text x={320} y={115}>Service</Text><Text x={550} y={115}>Identity</Text>
  <Text x={320} y={145} size={24}>provider</Text><Text x={550} y={145} size={24}>provider</Text>
  {[90,320,550].map(x=><path key={x} d={`M${x} 165V465`} stroke={C.textDim} strokeWidth={2} strokeDasharray="8 8"/>)}
  <Channel x1={550} y1={235} x2={90} y2={235} color={C.accent}/><Text x={330} y={207} color={C.accent}>Signed assertion</Text>
  <circle cx={90} cy={235} r={18} fill={alpha(C.accent,.2)} stroke={C.accent} strokeWidth={3}/>
  <Channel x1={90} y1={365} x2={320} y2={365} color={C.accent}/><Text x={203} y={333} color={C.accent}>Browser POST</Text>
  <Credential x={205} y={462} w={250} title="Validate → session" color={C.result}/>
</Canvas>;
const MutualCover=()=> <Canvas>
  <Actor x={100} y={150} label="Client" kind="device"/><Actor x={540} y={150} label="Server"/>
  <Channel x1={180} y1={295} x2={460} y2={295} color={C.accent}/><Text x={320} y={269} color={C.accent}>Certificate + proof</Text>
  <Channel x1={460} y1={365} x2={180} y2={365} color={C.result}/><Text x={320} y={411} color={C.result}>Certificate + proof</Text>
  {[110,530].map(x=><g key={x}><rect x={x-88} y={452} width={176} height={120} rx={15} fill={alpha(C.accent,.1)} stroke={C.accent} strokeWidth={3}/><KeyMark x={x} y={485} label=""/><Text x={x} y={547} size={24}>Key stays local</Text></g>)}
  <Text x={320} y={120} color={C.result}>Both peers</Text><Text x={320} y={155} color={C.result}>authenticated</Text>
</Canvas>;
const LeastCover=()=> <Canvas>
  <Channel x1={165} y1={300} x2={360} y2={160} color={C.result}/>
  <path d="M165 320L335 340M165 340L335 505" stroke={C.warn} strokeWidth={3} strokeDasharray="7 8"/>
  <Actor x={90} y={310} kind="person" label="Report reader"/>
  <Credential x={365} y={123} w={225} title="Read reports" color={C.result}/><CheckRow x={400} y={228} label="Keep" status="pass"/>
  <Credential x={365} y={307} w={225} title="Export all" color={C.warn}/>
  <Credential x={365} y={472} w={225} title="Admin settings" color={C.warn}/>
  {[340,505].map(y=><g key={y}><path d={`M312 ${y-18}L342 ${y+18}M342 ${y-18}L312 ${y+18}`} stroke={C.warn} strokeWidth={5}/></g>)}
  <Text x={475} y={422} color={C.warn}>Revoke excess</Text>
</Canvas>;
export const FIGURES3:Record<string,React.FC>={
  'role-based-access-control':RoleCover,
  'attribute-based-access-control':AttributeCover,
  'saml-service-provider-login-flow':SamlCover,
  'mutual-tls-certificate-authentication':MutualCover,
  'least-privilege-access-review':LeastCover,
};
