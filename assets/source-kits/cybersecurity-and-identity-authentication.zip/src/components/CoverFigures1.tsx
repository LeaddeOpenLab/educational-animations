import React from 'react';
import {COLORS as C,FONT,alpha} from '../theme';
import {Actor,KeyMark,CheckRow} from './Security';

const Canvas:React.FC<{children:React.ReactNode}>=({children})=><svg width={640} height={620} viewBox="0 0 640 620" style={{fontFamily:FONT}}>{children}</svg>;
const Txt:React.FC<{x:number;y:number;text:string;color?:string}>=({x,y,text,color=C.textStrong})=><text x={x} y={y} textAnchor="middle" fill={color} fontSize={25}>{text}</text>;
const Card:React.FC<{x:number;y:number;w:number;label:string;color?:string}>=({x,y,w,label,color=C.primary})=><g><rect x={x} y={y} width={w} height={70} rx={12} fill={C.bg1} stroke={color} strokeWidth={3}/><Txt x={x+w/2} y={y+44} text={label} color={color}/></g>;
const Path:React.FC<{d:string;color?:string}>=({d,color=C.primary})=><path d={d} fill="none" stroke={color} strokeWidth={4}/>;

const Boundary:React.FC=()=> <Canvas>
<Actor x={140} y={295} label="Maya" kind="person"/>
<CheckRow x={65} y={430} label="Verified identity" status="pass"/>
<Path d="M205 285L350 185H540" color={C.result}/><Path d="M205 315L350 445H545" color={C.warn}/>
<Card x={350} y={95} w={230} label="READ allowed" color={C.result}/>
<Card x={350} y={465} w={230} label="DELETE denied" color={C.warn}/>
<path d="M565 405V460" stroke={C.warn} strokeWidth={9}/>
<path d="M300 80V540" stroke={C.accent} strokeWidth={2} strokeDasharray="8 8"/>
<Txt x={445} y={325} text="Report permissions"/>
</Canvas>;

const Salt:React.FC=()=> <Canvas>
<Txt x={320} y={80} text="Same password · different salts"/>
{[0,1].map(i=><g key={i}>
<Card x={35} y={150+i*260} w={190} label="river-boat"/>
<Path d={`M225 ${185+i*260}H270`} />
<rect x={270} y={125+i*260} width={145} height={145} rx={16} fill={alpha(C.primary,.12)} stroke={C.primary} strokeWidth={3}/>
<Txt x={342} y={170+i*260} text="Argon2id"/>
<Txt x={342} y={225+i*260} text={i?'salt: 91':'salt: 7C'} color={C.accent}/>
<Path d={`M415 ${185+i*260}H445`} />
<Card x={445} y={150+i*260} w={165} label={i?'B9…21':'A4…D8'} color={i?C.primary:C.result}/>
</g>)}
<Txt x={320} y={585} text="Schematic verifiers" color={C.textMuted}/>
</Canvas>;

const Challenge:React.FC=()=> <Canvas><g transform="translate(0 -20)">
<rect x={35} y={100} width={235} height={430} rx={24} fill={alpha(C.primary,.08)} stroke={C.primary} strokeWidth={3}/>
<Txt x={152} y={155} text="Device vault"/>
<KeyMark x={140} y={340} label="Private key"/>
<Actor x={510} y={190} label="Server"/>
<KeyMark x={495} y={475} label="Public key" color={C.result}/>
<Path d="M450 245H225"/><Card x={300} y={235} w={170} label="Challenge"/>
<Path d="M225 410H510" color={C.accent}/><Card x={300} y={365} w={170} label="Signature" color={C.accent}/>
<Txt x={320} y={590} text="Proof travels. Private key stays." color={C.result}/>
</g></Canvas>;

const OAuth:React.FC=()=> <Canvas>
<Actor x={320} y={115} label="Browser" kind="device"/>
<Actor x={110} y={330} label="Client"/>
<Actor x={525} y={330} label="Auth server"/>
<Path d="M150 270L270 150M370 150L485 270"/>
<Card x={220} y={230} w={205} label="CODE" color={C.accent}/>
<Path d="M440 455H180" color={C.result}/>
<Card x={205} y={420} w={250} label="ACCESS TOKEN" color={C.result}/>
<Txt x={320} y={555} text="Redirect → exchange → API" color={C.result}/>
</Canvas>;

const IdentityToken:React.FC=()=> <Canvas><g transform="translate(0 -20)">
<Card x={35} y={105} w={265} label="photo-app token" color={C.result}/>
<Card x={340} y={105} w={265} label="other-app token" color={C.warn}/>
<CheckRow x={55} y={260} label="Signature valid" status="pass"/>
<CheckRow x={355} y={260} label="Signature valid" status="pass"/>
<CheckRow x={55} y={345} label="Audience fits" status="pass"/>
<CheckRow x={355} y={345} label="Wrong audience" status="fail"/>
<Path d="M165 380V460" color={C.result}/><Path d="M475 380V460" color={C.warn}/>
<Card x={45} y={470} w={245} label="ACCEPT" color={C.result}/>
<Card x={350} y={470} w={245} label="REJECT" color={C.warn}/>
<Txt x={320} y={590} text="Signature alone is insufficient"/>
</g></Canvas>;

export const FIGURES1:Record<string,React.FC>={
'authentication-and-authorization-boundary':Boundary,
'password-hashing-with-salt':Salt,
'public-key-challenge-response-authentication':Challenge,
'oauth-20-authorization-code-flow':OAuth,
'openid-connect-id-token-validation':IdentityToken,
};
