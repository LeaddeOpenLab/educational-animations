import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Video as V0} from './videos/se06-webauthn-passkey-registration';
import {Video as V1} from './videos/se07-multi-factor-authentication-totp';
import {Video as V2} from './videos/se08-session-cookie-secure-attributes';
import {Video as V3} from './videos/se09-json-web-token-signature-verification';
import {Video as V4} from './videos/se10-refresh-token-rotation';
const Root=()=> <><Composition id="se06-webauthn-passkey-registration" component={V0} durationInFrames={900} fps={30} width={1920} height={1080}/><Composition id="se07-multi-factor-authentication-totp" component={V1} durationInFrames={900} fps={30} width={1920} height={1080}/><Composition id="se08-session-cookie-secure-attributes" component={V2} durationInFrames={900} fps={30} width={1920} height={1080}/><Composition id="se09-json-web-token-signature-verification" component={V3} durationInFrames={900} fps={30} width={1920} height={1080}/><Composition id="se10-refresh-token-rotation" component={V4} durationInFrames={900} fps={30} width={1920} height={1080}/></>;
registerRoot(Root);
