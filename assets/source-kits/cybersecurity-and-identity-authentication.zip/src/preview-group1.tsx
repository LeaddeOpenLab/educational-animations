import React from 'react';
import {Composition,registerRoot} from 'remotion';
import V0 from './videos/se01-authentication-and-authorization-boundary';
import V1 from './videos/se02-password-hashing-with-salt';
import V2 from './videos/se03-public-key-challenge-response-authentication';
import V3 from './videos/se04-oauth-20-authorization-code-flow';
import V4 from './videos/se05-openid-connect-id-token-validation';
const Root=()=> <><Composition id="G1V1" component={V0} width={1920} height={1080} fps={30} durationInFrames={900}/><Composition id="G1V2" component={V1} width={1920} height={1080} fps={30} durationInFrames={900}/><Composition id="G1V3" component={V2} width={1920} height={1080} fps={30} durationInFrames={900}/><Composition id="G1V4" component={V3} width={1920} height={1080} fps={30} durationInFrames={960}/><Composition id="G1V5" component={V4} width={1920} height={1080} fps={30} durationInFrames={930}/></>;
registerRoot(Root);
