import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {COLORS,alpha} from '../theme';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Credential,Channel,KeyMark,CheckRow} from '../components/Security';
const T = {"topic": "SAML Service Provider Login Flow", "takeaway": "The service provider creates a session only after validating the returned SAML response and assertion."};
const DESIGN_AUDIT = {
  visualArgument: 'A three-lane sequence diagram traces browser-mediated messages and puts a visible validation gate before session creation.',
  motion: 'Messages move on separate noncrossing y-levels; final session opens only after checks.',
  example: 'SP-initiated login with HTTP Redirect request and HTTP POST response.',
  antiTemplate: 'The distinguishing feature is browser relay plus assertion validation, not generic two-endpoint exchange.',
  sceneRationale: 'request: The application has no authenticated session for this browser. Authentication is delegated using a SAML request. identity-provider: The browser carries the redirect and the identity provider authenticates the user. User authentication happens at the identity provider, not the application. post-response: The chosen redirect/POST binding sends the response through the user agent. The assertion reaches the service provider without a direct IdP-to-SP backchannel in this example. validate: The service provider must trust and validate the response and assertion before accepting the identity. The application opens after validation, not merely because a signed-looking envelope arrived.'
};
const SCENE_PLAN = [{"id": "request", "start_seconds": 0, "end_seconds": 6, "heading": "Start at the service provider", "lines": ["Browser requests the application.", "No session \u2192 authentication request"], "objects": ["Browser lane x140", "Service provider lane x500", "Identity provider lane x860", "time downward y170\u2013580"], "change": "Browser-to-service arrow travels right; service emits AuthnRequest back to Browser.", "cause": "The application has no authenticated session for this browser.", "result": "Authentication is delegated using a SAML request.", "reading_seconds": 3.0, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "identity-provider", "start_seconds": 6, "end_seconds": 13, "heading": "Browser follows the redirect", "lines": ["AuthnRequest reaches the identity provider.", "The user authenticates there."], "objects": ["AuthnRequest envelope", "browser relay path", "identity provider login card"], "change": "Envelope travels from service via Browser to Identity provider; login card reveals a verified user badge.", "cause": "The browser carries the redirect and the identity provider authenticates the user.", "result": "User authentication happens at the identity provider, not the application.", "reading_seconds": 3.0, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "post-response", "start_seconds": 13, "end_seconds": 21, "heading": "Return a signed assertion", "lines": ["SAMLResponse travels through the browser.", "POST to the service provider"], "objects": ["signed assertion envelope", "browser form relay", "service assertion consumer endpoint"], "change": "Signed envelope leaves Identity provider, arrives at Browser, then follows a separate POST path to Service provider. Each traversed leg remains as a thin trail.", "cause": "The chosen redirect/POST binding sends the response through the user agent.", "result": "The assertion reaches the service provider without a direct IdP-to-SP backchannel in this example.", "reading_seconds": 3.3, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "validate", "start_seconds": 21, "end_seconds": 31, "heading": "Validate before opening a session", "lines": ["Check signature, audience and time.", "Match the request, then create a session."], "objects": ["validation gate inside Service provider", "four checks", "application session card"], "change": "Envelope waits at gate; signature, audience, expiry and request-correlation checks light in sequence; only then session card unfolds and browser receives session indication.", "cause": "The service provider must trust and validate the response and assertion before accepting the identity.", "result": "The application opens after validation, not merely because a signed-looking envelope arrived.", "reading_seconds": 4.0, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Txt=({x,y,children,color=COLORS.textStrong,size=27}:{x:number;y:number;children:React.ReactNode;color?:string;size?:number})=><text x={x} y={y} textAnchor="middle" fill={color} fontSize={size}>{children}</text>;
const Box=({x,y,w=240,label,color=COLORS.primary}:{x:number;y:number;w?:number;label:string;color?:string})=><g><rect x={x-w/2} y={y-38} width={w} height={76} rx={14} fill={alpha(color,.12)} stroke={color} strokeWidth={3}/><Txt x={x} y={y+9} color={color}>{label}</Txt></g>;
export const stateAt=(t:number)=>({leg1:p(t,13.4,16),leg2:p(t,16.5,19),arrived:t>=19});
const Diagram:React.FC<{t:number}>=({t})=>{const s=stateAt(t);
if(t<13){const r=p(t,1,2.5),back=p(t,3,5),relay=p(t,6.5,9);return <>
{[[140,'Browser'],[500,'Service provider'],[860,'Identity provider']].map(([x,n])=><g key={String(n)}><Txt x={Number(x)} y={90} size={25}>{n}</Txt><path d={`M${x} 120V590`} stroke={COLORS.textDim} strokeWidth={2} strokeDasharray="7 7"/></g>)}
<Channel x1={140} y1={210} x2={500} y2={210} progress={r} packet={r}/><Txt x={325} y={180}>Application request</Txt>
{t>=3&&<><Channel x1={500} y1={320} x2={140} y2={320} progress={back} packet={back} color={COLORS.accent}/><Txt x={320} y={285}>AuthnRequest</Txt></>}
{t>=6.5&&<><Channel x1={140} y1={445} x2={860} y2={445} progress={relay} packet={relay} color={COLORS.accent}/><Txt x={500} y={410}>Browser redirect</Txt></>}
{t>=9&&<><Box x={820} y={555} label={t>=11?'User verified':'User authenticates'} w={330} color={t>=11?COLORS.result:COLORS.accent}/>{t>=11&&<CheckRow x={740} y={650} label="Identity checked" status="pass"/>}</>}
</>}
if(t>=21){const checks=['Signature','Audience','Validity window','Request correlation'];const done=t>=27;return <><Txt x={500} y={90} size={32}>Service provider validation</Txt><Credential x={95} y={260} w={275} title="SAML assertion"/><Channel x1={375} y1={290} x2={505} y2={290} color={COLORS.accent}/>{checks.map((c,i)=><CheckRow key={c} x={570} y={190+i*82} label={c} status={t>=22+i*1.5?'pass':'pending'}/>)}{done&&<><Box x={510} y={600} label="Application session created" w={480} color={COLORS.result}/><Channel x1={600} y1={475} x2={510} y2={555} progress={p(t,27,28)} color={COLORS.result}/></>}</>}
return <>
{[[140,'Browser'],[500,'Service provider'],[860,'Identity provider']].map(([x,n])=><g key={String(n)}><Txt x={Number(x)} y={90} size={25}>{n}</Txt><path d={`M${x} 120V580`} stroke={COLORS.textDim} strokeWidth={2} strokeDasharray="7 7"/></g>)}
<Txt x={500} y={185} color={COLORS.accent}>Signed SAMLResponse</Txt><Channel x1={860} y1={250} x2={140} y2={250} progress={s.leg1} packet={s.leg1} color={COLORS.accent}/>
{s.leg1===1&&<><circle cx={140} cy={250} r={24} stroke={COLORS.accent} fill={alpha(COLORS.accent,.2)}/><Txt x={180} y={325}>Browser relay</Txt></>}
{s.leg2>0&&<><Channel x1={140} y1={400} x2={500} y2={400} progress={s.leg2} packet={s.leg2} color={COLORS.accent}/><Txt x={330} y={365}>HTTP POST</Txt></>}
{s.arrived&&<><Box x={500} y={520} label="Validate assertion" w={295} color={COLORS.accent}/><Txt x={500} y={635}>No application session yet</Txt></>}
</>};
const Scene:React.FC<{frame:number;index:number}>=({frame,index})=>{const scene=SCENE_PLAN[index];const t=frame/30+scene.start_seconds;return <LessonFrame topic={T.topic} heading={scene.heading} lines={scene.lines} takeaway={T.takeaway} frame={frame} step={index+1} steps={SCENE_PLAN.length}><Diagram t={t}/></LessonFrame>};
const Scene1:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={0}/>;
const Scene2:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={1}/>;
const Scene3:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={2}/>;
const Scene4:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={3}/>;
export const SCENES:SceneDef[] = [
  {id:'request',Comp:Scene1,dur:180},
  {id:'identity-provider',Comp:Scene2,dur:210},
  {id:'post-response',Comp:Scene3,dur:240},
  {id:'validate',Comp:Scene4,dur:300},
];
export const Video=makeVideo(SCENES);
export default Video;
