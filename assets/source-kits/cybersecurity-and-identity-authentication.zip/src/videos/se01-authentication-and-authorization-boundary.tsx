import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Gate,KeyMark,CheckRow} from '../components/Security';
import {COLORS as C,alpha} from '../theme';
const T = {"topic": "Authentication and Authorization Boundary", "takeaway": "A verified identity still needs permission for each requested action."};
const DESIGN_AUDIT = {
  visualArgument: 'One verified person forks into successful read and denied delete routes.',
  motion: 'Identity crosses the first gate; action packets cross or rebound from separate permission gates.',
  example: 'Maya can read a report but cannot delete it.',
  antiTemplate: 'A spatial fork and unchanged identity badge demonstrate the boundary; this is not a protocol swimlane.',
  sceneRationale: 'Identity first, two contrasting actions next, shared-boundary summary last.'
};
const SCENE_PLAN = [{"id": "identify", "start_seconds": 0, "end_seconds": 7, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Who are you?", "objects": ["Maya identity card", "identity gate", "document workspace"], "change": "Maya card moves through identity gate; a verified check appears without opening resource doors.", "cause": "The credential check identifies Maya.", "result": "Identity is verified; permissions remain undecided.", "lines": ["Authentication verifies identity."]}, {"id": "read", "start_seconds": 7, "end_seconds": 15, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "May Maya read?", "objects": ["verified Maya badge", "READ request packet", "report door", "policy: read allowed"], "change": "READ packet leaves Maya, meets policy marker, and enters the opened report door; report page expands.", "cause": "Maya has read permission on the report.", "result": "The read request succeeds.", "lines": ["Same identity. Read is allowed."]}, {"id": "delete", "start_seconds": 15, "end_seconds": 24, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "May Maya delete?", "objects": ["same verified badge", "DELETE request", "report door", "policy: delete denied"], "change": "DELETE packet takes a separate lower route and stops at a closed permission gate; report stays intact.", "cause": "Delete permission is absent even though identity is unchanged.", "result": "The delete request is denied.", "lines": ["Identity stays verified. Delete is denied."]}, {"id": "boundary", "start_seconds": 24, "end_seconds": 30, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Check every action", "objects": ["read route", "delete route", "identity gate", "authorization boundary"], "change": "Two routes resolve simultaneously into green READ and red DELETE outcomes; a boundary line brackets the per-action checks.", "cause": "Authorization evaluates the requested resource and operation.", "result": "One person can receive different access decisions.", "lines": ["Authentication: identity", "Authorization: allowed action"]}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Label=({x,y,text,color=C.textStrong,size=28}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} textAnchor="middle">{text}</text>;
const Box=({x,y,w=240,h=80,text,color=C.primary}:{x:number;y:number;w?:number;h?:number;text:string;color?:string})=><g><rect x={x} y={y} width={w} height={h} rx={14} fill={C.bg1} stroke={color} strokeWidth={3}/><Label x={x+w/2} y={y+h/2+10} text={text} color={color}/></g>;
const Line=({x1,y1,x2,y2,color=C.primary}:{x1:number;y1:number;x2:number;y2:number;color?:string})=><path d={`M${x1} ${y1}L${x2} ${y2}`} stroke={color} strokeWidth={3} fill="none"/>;

export const deriveState=(t:number)=>({identity:p(t,1,4),verified:t>=4,read:p(t,8,12),deny:p(t,16,20),showRead:t>=7,showDelete:t>=15});
function Diagram({t}:{t:number}){const s=deriveState(t);return <>
<Actor x={120+160*s.identity} y={330} label="Maya" kind="person"/><g transform="translate(0 0)" style={{fontSize:24}}><Gate x={440} y={330} label="Identity" open={s.verified}/></g>
{s.verified&&<CheckRow x={170} y={480} label="Identity verified" status="pass"/>}
{s.showRead&&<><Line x1={500} y1={320} x2={810} y2={180}/><Box x={730} y={90} w={220} text="Report" color={C.result}/><Box x={500+230*s.read} y={230-50*s.read} w={180} h={66} text="READ" color={C.result}/>{s.read===1&&<><Label x={840} y={325} text="ALLOWED" color={C.result}/></>}</>}
{s.showDelete&&<><Line x1={500} y1={380} x2={790} y2={500} color={C.warn}/><Box x={500+110*s.deny} y={400+70*s.deny} w={180} h={66} text="DELETE" color={C.warn}/><path d="M825 420V580" stroke={C.warn} strokeWidth={10}/>{s.deny===1&&<Label x={795} y={630} text="DENIED" color={C.warn}/>}</>}
{t>=24&&<g opacity={p(t,24,26)}><path d="M480 65V655" stroke={C.accent} strokeWidth={3} strokeDasharray="10 8"/><Label x={710} y={50} text="Per-action permissions" color={C.accent}/></g>}
</>}


const Identify: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Who are you?'} lines={["Authentication verifies identity."]} takeaway={T.takeaway} frame={frame} step={1} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={0+frame/30}/></g>
  </LessonFrame>
);

const Read: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'May Maya read?'} lines={["Same identity. Read is allowed."]} takeaway={T.takeaway} frame={frame} step={2} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={7+frame/30}/></g>
  </LessonFrame>
);

const Delete: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'May Maya delete?'} lines={["Identity stays verified. Delete is denied."]} takeaway={T.takeaway} frame={frame} step={3} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={15+frame/30}/></g>
  </LessonFrame>
);

const Boundary: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Check every action'} lines={["Authentication: identity", "Authorization: allowed action"]} takeaway={T.takeaway} frame={frame} step={4} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={24+frame/30}/></g>
  </LessonFrame>
);

export const SCENES: SceneDef[] = [
  {id:'identify',Comp:Identify,dur:210},
  {id:'read',Comp:Read,dur:240},
  {id:'delete',Comp:Delete,dur:270},
  {id:'boundary',Comp:Boundary,dur:180}
];
export default makeVideo(SCENES);
