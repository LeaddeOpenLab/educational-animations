import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Gate,KeyMark,CheckRow} from '../components/Security';
import {COLORS as C,alpha} from '../theme';
const T = {"topic": "OpenID Connect ID Token Validation", "takeaway": "Validate issuer, audience, expiry and request binding as well as the signature before accepting identity."};
const DESIGN_AUDIT = {
  visualArgument: 'Layered verification preserves signature success while audience mismatch causes rejection.',
  motion: 'Claims unfold, scanner checks rows, correct and wrong-audience cards split into different results.',
  example: 'Client photo-app accepts Maya token only when audience includes photo-app.',
  antiTemplate: 'A token inspection panel and clone comparison distinguish this from JWT signature-only lesson.',
  sceneRationale: 'Stage integrity before context checks, then falsify signature-alone misconception.'
};
const SCENE_PLAN = [{"id": "token", "start_seconds": 0, "end_seconds": 6, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "An ID Token makes a claim", "objects": ["ID Token card", "subject Maya", "untrusted identity silhouette"], "change": "Token card opens to reveal issuer, audience, expiry and nonce rows; Maya silhouette stays gray.", "cause": "The client has received a token but has not validated it.", "result": "Claims are visible, not yet trusted.", "lines": ["Decoded does not mean trusted."]}, {"id": "signature", "start_seconds": 6, "end_seconds": 13, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Check the signature", "objects": ["token signed envelope", "trusted issuer key", "signature scanner"], "change": "Trusted issuer key activates envelope verification; signature badge turns green while identity remains gray.", "cause": "The cryptographic signature verifies under the expected issuer key and allowed algorithm.", "result": "Integrity check passes but claim checks remain pending.", "lines": ["Signature valid is only one check."]}, {"id": "claims", "start_seconds": 13, "end_seconds": 23, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Check who, where and when", "objects": ["issuer row", "audience row", "expiry clock", "nonce request chip", "validation rail"], "change": "A scanning rail visits issuer, audience, expiry and nonce; each row aligns with expected client context and changes to green.", "cause": "Issuer is expected; audience includes this client; expiry is future; nonce matches the one sent.", "result": "All illustrated claim checks pass.", "lines": ["Expected issuer and audience", "Valid time and matching nonce"]}, {"id": "reject", "start_seconds": 23, "end_seconds": 31, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "A wrong audience still fails", "objects": ["green original token", "clone with audience other-app", "accept lane", "reject lane"], "change": "Two token cards separate; original goes to accepted Maya identity while changed-audience token stops in a red lane despite retaining a green signature badge.", "cause": "A token intended for another client must not establish this client\u2019s user session.", "result": "Claim mismatch prevents acceptance even with a valid signature.", "lines": ["Valid signature + wrong audience \u2192 reject"]}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Label=({x,y,text,color=C.textStrong,size=28}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} textAnchor="middle">{text}</text>;
const Box=({x,y,w=240,h=80,text,color=C.primary}:{x:number;y:number;w?:number;h?:number;text:string;color?:string})=><g><rect x={x} y={y} width={w} height={h} rx={14} fill={C.bg1} stroke={color} strokeWidth={3}/><Label x={x+w/2} y={y+h/2+10} text={text} color={color}/></g>;
const Line=({x1,y1,x2,y2,color=C.primary}:{x1:number;y1:number;x2:number;y2:number;color?:string})=><path d={`M${x1} ${y1}L${x2} ${y2}`} stroke={color} strokeWidth={3} fill="none"/>;

export const deriveState=(t:number)=>({signed:t>=10,checks:[t>=15,t>=17,t>=19,t>=21],split:p(t,24,27),reject:t>=27});
function Diagram({t}:{t:number}){const s=deriveState(t);return <>
{t<23?<><rect x={120} y={70} width={740} height={535} rx={22} fill={alpha(C.primary,.08)} stroke={C.primary} strokeWidth={3}/><Label x={490} y={130} text="ID TOKEN · Maya" size={34}/><CheckRow x={180} y={195} label="Signature" status={s.signed?'pass':'pending'}/>{['Issuer: login.example','Audience: photo-app','Expiry: still valid','Nonce: N7 = request N7'].map((v,i)=><CheckRow key={v} x={180} y={280+i*75} label={v} status={s.checks[i]?'pass':'pending'}/>)}{t>=13&&<rect x={155} y={243+Math.min(3,Math.floor((t-13)/2))*75} width={655} height={60} rx={10} fill="none" stroke={C.accent} strokeWidth={3}/>}<Label x={490} y={670} text={s.checks.every(Boolean)?'Context checks passed':'Identity not accepted yet'} color={s.checks.every(Boolean)?C.result:C.textMuted}/></>:<>
<Box x={100-30*s.split} y={90} w={370} h={85} text="Token for photo-app" color={C.result}/><Box x={490+30*s.split} y={90} w={390} h={85} text="Token for other-app" color={C.warn}/>
<CheckRow x={90} y={245} label="Signature valid" status="pass"/><CheckRow x={540} y={245} label="Signature valid" status="pass"/>
<CheckRow x={90} y={335} label="Audience matches" status="pass"/><CheckRow x={540} y={335} label="Audience mismatch" status={s.reject?'fail':'pending'}/>
<Line x1={260} y1={390} x2={260} y2={450+80*s.split} color={C.result}/><Line x1={730} y1={390} x2={730} y2={430+30*s.split} color={C.warn}/>
{s.reject&&<><Box x={90} y={540} w={350} text="Accept identity" color={C.result}/><Box x={540} y={480} w={350} text="REJECT" color={C.warn}/><Label x={715} y={650} text="Separately issued token" size={24}/></>}
</>}
</>}


const Token: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'An ID Token makes a claim'} lines={["Decoded does not mean trusted."]} takeaway={T.takeaway} frame={frame} step={1} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={0+frame/30}/></g>
  </LessonFrame>
);

const Signature: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Check the signature'} lines={["Signature valid is only one check."]} takeaway={T.takeaway} frame={frame} step={2} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={6+frame/30}/></g>
  </LessonFrame>
);

const Claims: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Check who, where and when'} lines={["Expected issuer and audience", "Valid time and matching nonce"]} takeaway={T.takeaway} frame={frame} step={3} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={13+frame/30}/></g>
  </LessonFrame>
);

const Reject: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'A wrong audience still fails'} lines={["Valid signature + wrong audience \u2192 reject"]} takeaway={T.takeaway} frame={frame} step={4} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={23+frame/30}/></g>
  </LessonFrame>
);

export const SCENES: SceneDef[] = [
  {id:'token',Comp:Token,dur:180},
  {id:'signature',Comp:Signature,dur:210},
  {id:'claims',Comp:Claims,dur:300},
  {id:'reject',Comp:Reject,dur:240}
];
export default makeVideo(SCENES);
