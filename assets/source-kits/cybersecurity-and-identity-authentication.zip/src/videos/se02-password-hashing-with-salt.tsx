import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Gate,KeyMark,CheckRow} from '../components/Security';
import {COLORS as C,alpha} from '../theme';
const T = {"topic": "Password Hashing with Salt", "takeaway": "A unique random salt changes each stored password hash; verification reuses that account\u2019s salt."};
const DESIGN_AUDIT = {
  visualArgument: 'Parallel computation lanes differ only in salt, then one lane is replayed for verification.',
  motion: 'Salt merges into KDF; outputs diverge; stored salt returns for a compare operation.',
  example: 'Two river-boat passwords receive schematic salts 7C and 91.',
  antiTemplate: 'A two-lane data transformation followed by a feedback loop, not a security gate sequence.',
  sceneRationale: 'Establish equal inputs, isolate changed salt, persist state, verify by reuse.'
};
const SCENE_PLAN = [{"id": "equal", "start_seconds": 0, "end_seconds": 6, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Same password, two accounts", "objects": ["account A password", "account B password", "two empty storage rows"], "change": "Two equal password tiles align vertically; equal symbols appear between them.", "cause": "Two users chose the same example password.", "result": "Without added context the inputs are identical.", "lines": ["Illustrative password: river-boat"]}, {"id": "salt", "start_seconds": 6, "end_seconds": 14, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Add a different salt", "objects": ["salt A: 7C", "salt B: 91", "two password KDF machines", "two verifier tiles"], "change": "Distinct salt tiles enter separate password KDF machines with equal passwords; different verifier patterns emerge.", "cause": "Each account receives a unique random salt.", "result": "Different salted inputs produce different verifiers.", "lines": ["Use a password KDF, such as Argon2id.", "Values shown are schematic."]}, {"id": "store", "start_seconds": 14, "end_seconds": 20, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Store salt + verifier", "objects": ["database rows A and B", "salt and verifier tiles", "password tiles"], "change": "A database with separate Salt and Verifier columns appears. Both salt and verifier tiles move into account rows while the plaintext password and KDF tiles fade away; the database contains no plaintext password.", "cause": "The salt need not be secret; plaintext passwords are not stored.", "result": "Two account rows store their own salt and verifier; plaintext inputs are discarded.", "lines": ["Salt is stored with the verifier."]}, {"id": "verify", "start_seconds": 20, "end_seconds": 30, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Recompute to verify", "objects": ["login input", "stored salt A", "same KDF", "computed verifier", "stored verifier A"], "change": "Stored salt A travels back into the KDF with the login input; computed verifier aligns with stored A and the match check lights.", "cause": "A correct password with the same salt and KDF parameters reproduces the stored verifier.", "result": "Matching verifiers approve the password check.", "lines": ["Same input + same salt \u2192 matching verifier"]}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Label=({x,y,text,color=C.textStrong,size=28}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} textAnchor="middle">{text}</text>;
const Box=({x,y,w=240,h=80,text,color=C.primary}:{x:number;y:number;w?:number;h?:number;text:string;color?:string})=><g><rect x={x} y={y} width={w} height={h} rx={14} fill={C.bg1} stroke={color} strokeWidth={3}/><Label x={x+w/2} y={y+h/2+10} text={text} color={color}/></g>;
const Line=({x1,y1,x2,y2,color=C.primary}:{x1:number;y1:number;x2:number;y2:number;color?:string})=><path d={`M${x1} ${y1}L${x2} ${y2}`} stroke={color} strokeWidth={3} fill="none"/>;

export const deriveState=(t:number)=>({salt:p(t,6,9),hash:p(t,9,13),stored:p(t,14,18),verify:p(t,21,27),verifying:t>=20});
function Diagram({t}:{t:number}){const s=deriveState(t);return <>
{t>=14&&t<20?<>
<g opacity={p(t,14,15.2)}><rect x={510} y={70} width={460} height={510} rx={22} fill={C.bg1} stroke={C.result} strokeWidth={3}/><g opacity={p(t,17,18)}><Label x={740} y={120} text="ACCOUNT DATABASE" color={C.result}/><Label x={620} y={160} text="Salt"/><Label x={840} y={160} text="Verifier"/></g><path d="M525 370H955" stroke={C.textMuted}/></g>
{[0,1].map(i=>{const y=110+i*280,store=p(t,15,18),target=220+i*220;return <g key={i}>
<g opacity={1-p(t,14.5,17)}><Box x={40} y={y} w={270} text="river-boat"/><Box x={350} y={y} w={230} text="Argon2id"/></g>
<Box x={330+210*store} y={y+125+(target-y-125)*store} w={180} h={70} text={i?'91':'7C'} color={C.accent}/>
<Box x={680+70*store} y={y+(target-y)*store} w={180} h={70} text={i?'B9…21':'A4…D8'} color={i?C.alt:C.result}/>
{store===1&&<Label x={740} y={target+112} text={`Account ${i?'B':'A'}`} color={C.textMuted}/>}</g>})}
<Label x={500} y={635} text="Store salt + verifier. Discard plaintext." color={C.result}/>
</>:!s.verifying?[0,1].map(i=>{const y=110+i*280;return <g key={i}><Label x={170} y={y-25} text={`Account ${i?'B':'A'}`}/><Box x={40} y={y} w={270} text="river-boat"/><Box x={350} y={y} w={230} text="Argon2id"/><Line x1={310} y1={y+40} x2={350} y2={y+40}/><g opacity={s.salt}><Line x1={465} y1={y+80} x2={465} y2={y+125} color={C.accent}/><Box x={330} y={y+155-30*s.salt} w={270} h={65} text={`salt: ${i?'91':'7C'}`} color={C.accent}/></g><g opacity={s.hash}><Line x1={580} y1={y+40} x2={675} y2={y+40}/><Box x={680} y={y} w={260} text={i?'B9…21':'A4…D8'} color={i?C.alt:C.result}/></g><g opacity={s.stored}><Label x={810} y={y+135} text={`stored salt: ${i?'91':'7C'}`} color={C.accent}/></g></g>}):<>
<Box x={30} y={100} w={280} text="river-boat"/><Box x={365} y={220} w={260} text="Argon2id"/><Box x={700} y={90} w={250} text="salt: 7C" color={C.accent}/><Line x1={300} y1={180} x2={365} y2={245}/><Line x1={825} y1={170} x2={625} y2={245} color={C.accent}/><circle cx={825-200*p(t,21,23)} cy={170+75*p(t,21,23)} r={11} fill={C.accent}/><Box x={130} y={440} w={280} text="stored A4…D8" color={C.result}/><g opacity={p(t,24,26)}><Box x={600} y={440} w={280} text="new A4…D8" color={C.result}/><Line x1={495} y1={300} x2={740} y2={440}/></g>{s.verify===1&&<Label x={500} y={585} text="MATCH" color={C.result} size={38}/>}</>}
<Label x={500} y={680} text="Schematic salts and verifiers" color={C.textMuted} size={24}/>
</>}


const Equal: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Same password, two accounts'} lines={["Illustrative password: river-boat"]} takeaway={T.takeaway} frame={frame} step={1} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={0+frame/30}/></g>
  </LessonFrame>
);

const Salt: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Add a different salt'} lines={["Use a password KDF, such as Argon2id.", "Values shown are schematic."]} takeaway={T.takeaway} frame={frame} step={2} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={6+frame/30}/></g>
  </LessonFrame>
);

const Store: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Store salt + verifier'} lines={["Salt is stored with the verifier."]} takeaway={T.takeaway} frame={frame} step={3} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={14+frame/30}/></g>
  </LessonFrame>
);

const Verify: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Recompute to verify'} lines={["Same input + same salt \u2192 matching verifier"]} takeaway={T.takeaway} frame={frame} step={4} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={20+frame/30}/></g>
  </LessonFrame>
);

export const SCENES: SceneDef[] = [
  {id:'equal',Comp:Equal,dur:180},
  {id:'salt',Comp:Salt,dur:240},
  {id:'store',Comp:Store,dur:180},
  {id:'verify',Comp:Verify,dur:300}
];
export default makeVideo(SCENES);
