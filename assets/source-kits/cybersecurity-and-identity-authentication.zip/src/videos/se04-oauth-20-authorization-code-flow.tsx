import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Gate,KeyMark,CheckRow} from '../components/Security';
import {COLORS as C,alpha} from '../theme';
const T = {"topic": "OAuth 2.0 Authorization Code Flow", "takeaway": "The browser carries an authorization code; the client exchanges it for an access token."};
const DESIGN_AUDIT = {
  visualArgument: 'Top browser redirect route and bottom direct exchange route carry different objects.',
  motion: 'Request redirects, code returns, code consumed, token issued, photos fetched.',
  example: 'A client obtains read-photos access using authorization code and PKCE.',
  antiTemplate: 'Three-party routed sequence with token and code shape distinction, not a generic pass/fail gate.',
  sceneRationale: 'Allocate longer exchange window because two credentials and two transport routes must be distinguished.'
};
const SCENE_PLAN = [{"id": "request", "start_seconds": 0, "end_seconds": 8, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Request permission", "objects": ["browser", "client app", "authorization server", "request arrow", "PKCE challenge"], "change": "The Request + PKCE tile follows the client-to-authorization-server redirect arc below the Browser label; Browser redirects label is above the browser to keep text distinct.", "cause": "The client requests permission to read photos and binds the later exchange to its verifier.", "result": "User arrives at the authorization server.", "lines": ["Example scope: read photos"]}, {"id": "redirect", "start_seconds": 8, "end_seconds": 15, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Return a code", "objects": ["consent panel", "browser", "client callback", "code C1"], "change": "Consent check appears; a short CODE C1 ticket moves along browser redirect path back to the client.", "cause": "The user grants the request and the authorization server issues a code.", "result": "Client receives a code via the browser.", "lines": ["Browser redirect carries a code."]}, {"id": "exchange", "start_seconds": 15, "end_seconds": 24, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Exchange code for token", "objects": ["client", "token endpoint", "code C1", "PKCE verifier", "access token"], "change": "Client sends CODE C1 and verifier along a distinct lower direct channel; code turns consumed as an ACCESS TOKEN returns.", "cause": "The token endpoint validates the code and verifier before issuing a token.", "result": "Client receives the access token through the token response.", "lines": ["Direct exchange: code + verifier", "Access token returns to the client."]}, {"id": "resource", "start_seconds": 24, "end_seconds": 32, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Use the access token", "objects": ["client", "photo API", "access token", "photo thumbnails"], "change": "The view switches to Client and Photo API. The access token moves from client to API along the upper request route. Only after the API token-accepted check appears do three photo cards return along a separate lower route to the client.", "cause": "The access token authorizes the resource request.", "result": "Client receives photos only after token acceptance by the resource API.", "lines": ["Access token \u2192 resource API", "The code is not an API credential."]}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Label=({x,y,text,color=C.textStrong,size=28}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} textAnchor="middle">{text}</text>;
const Box=({x,y,w=240,h=80,text,color=C.primary}:{x:number;y:number;w?:number;h?:number;text:string;color?:string})=><g><rect x={x} y={y} width={w} height={h} rx={14} fill={C.bg1} stroke={color} strokeWidth={3}/><Label x={x+w/2} y={y+h/2+10} text={text} color={color}/></g>;
const Line=({x1,y1,x2,y2,color=C.primary}:{x1:number;y1:number;x2:number;y2:number;color?:string})=><path d={`M${x1} ${y1}L${x2} ${y2}`} stroke={color} strokeWidth={3} fill="none"/>;

export const deriveState=(t:number)=>({request:p(t,1,5),code:p(t,9,13),exchange:p(t,16,19),token:p(t,20,23),photos:p(t,26,29)});
function Diagram({t}:{t:number}){const s=deriveState(t);
if(t>=24){const send=p(t,24.5,27),reply=p(t,28,30.8);return <>
<Actor x={140} y={280} label="Client"/><Actor x={830} y={280} label="Photo API" color={C.result}/>
<Label x={500} y={75} text="Use the token at the resource API" color={C.result}/>
<Line x1={235} y1={190} x2={750} y2={190} color={C.result}/>
<Box x={170+490*send} y={135} w={260} h={75} text="ACCESS TOKEN" color={C.result}/>
{send===1&&<CheckRow x={660} y={430} label="Token accepted" status="pass"/>}
{t>=28&&<><Line x1={770} y1={530} x2={230} y2={530} color={C.primary}/><g transform={`translate(${680-440*reply},475)`}>{[0,1,2].map(i=><g key={i}><rect x={i*70} y={0} width={60} height={90} rx={7} fill={C.bg1} stroke={C.primary} strokeWidth={3}/><circle cx={i*70+42} cy={20} r={7} fill={C.accent}/><path d={`M${i*70+8} 73L${i*70+26} 43L${i*70+50} 73Z`} fill={C.primary}/></g>)}</g></>}
<Label x={500} y={650} text={reply===1?'Photos received within granted scope':'Request first. Photos follow acceptance.'} color={C.result}/>
</>}
return <>
<Actor x={130} y={300} label="Client"/><Actor x={500} y={85} label="Browser" kind="device"/><Actor x={850} y={300} label="Auth server"/>
<path d="M150 250L460 80M550 80L830 250" stroke={C.primary} strokeWidth={3} fill="none"/><Label x={500} y={25} text="Browser redirects" size={24}/>
{t<8&&<Box x={180+440*s.request} y={210-40*Math.sin(s.request*Math.PI)} w={240} h={65} text="Request + PKCE"/>}
{t>=8&&t<15&&<Box x={690-520*s.code} y={210-40*Math.sin(s.code*Math.PI)} w={180} h={65} text="CODE C1" color={C.accent}/>}
{t>=15&&<><Line x1={220} y1={430} x2={760} y2={430} color={C.accent}/><Line x1={760} y1={545} x2={220} y2={545} color={C.result}/><Box x={210+410*s.exchange} y={397} w={280} h={65} text={s.exchange===1?'Code consumed':'Code + verifier'} color={C.accent}/>{t>=20&&<Box x={660-470*s.token} y={510} w={260} h={65} text="ACCESS TOKEN" color={C.result}/>}<Label x={490} y={640} text="Direct token exchange" size={26}/></>}

</>}


const Request: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Request permission'} lines={["Example scope: read photos"]} takeaway={T.takeaway} frame={frame} step={1} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={0+frame/30}/></g>
  </LessonFrame>
);

const Redirect: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Return a code'} lines={["Browser redirect carries a code."]} takeaway={T.takeaway} frame={frame} step={2} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={8+frame/30}/></g>
  </LessonFrame>
);

const Exchange: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Exchange code for token'} lines={["Direct exchange: code + verifier", "Access token returns to the client."]} takeaway={T.takeaway} frame={frame} step={3} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={15+frame/30}/></g>
  </LessonFrame>
);

const Resource: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Use the access token'} lines={["Access token \u2192 resource API", "The code is not an API credential."]} takeaway={T.takeaway} frame={frame} step={4} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={24+frame/30}/></g>
  </LessonFrame>
);

export const SCENES: SceneDef[] = [
  {id:'request',Comp:Request,dur:240},
  {id:'redirect',Comp:Redirect,dur:210},
  {id:'exchange',Comp:Exchange,dur:270},
  {id:'resource',Comp:Resource,dur:240}
];
export default makeVideo(SCENES);
