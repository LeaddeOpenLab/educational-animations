import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {COLORS,alpha} from '../theme';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Credential,Channel,KeyMark,CheckRow} from '../components/Security';
const T = {"topic": "Role-Based Access Control", "takeaway": "Permissions attach to roles; an active assigned role mediates the user\u2019s operations."};
const DESIGN_AUDIT = {
  visualArgument: 'The authorized operation exists only at the end of a continuous user → active role → permission path.',
  motion: 'Tokens traverse valid paths; a denied request stops at a broken path; the role change rewires the graph.',
  example: 'A report analyst reads but cannot delete until reassigned and activated as Administrator.',
  antiTemplate: 'This is an assignment graph with session activation, unlike ABAC’s attribute predicate evaluation.',
  sceneRationale: 'role-graph: Permission assignments belong to roles, while the user has a separate role assignment. Maya has one assigned role and no Administrator assignment. activate: The active Analyst role has Read permission. The report card opens only when the token reaches its authorized operation. deny-delete: Analyst lacks Delete, and Maya cannot activate unassigned Administrator. No effective permission path reaches Delete; denial is tied to the missing relationship. role-change: The user’s assignment and active role changed, not the report’s identity. One role change changes the operations available to the session.'
};
const SCENE_PLAN = [{"id": "role-graph", "start_seconds": 0, "end_seconds": 6, "heading": "Roles organize permissions", "lines": ["Maya is assigned the Analyst role."], "objects": ["Maya at (120,340)", "Analyst role at (440,280)", "Administrator role at (440,510)", "Read report and Delete report at (820,250/470)"], "change": "User-to-Analyst edge draws; two permission edges fan out from different roles. Analyst links to Read only; Administrator links to both.", "cause": "Permission assignments belong to roles, while the user has a separate role assignment.", "result": "Maya has one assigned role and no Administrator assignment.", "reading_seconds": 2, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "activate", "start_seconds": 6, "end_seconds": 12, "heading": "Activate an assigned role", "lines": ["Session: Analyst", "Read report is permitted."], "objects": ["session ring around Analyst", "Read request token", "Opened report page at x727 y550 width180 height100, below all permission nodes"], "change": "Session ring closes around Analyst; request traverses Maya \u2192 Analyst \u2192 Read. Once allowed, the report page opens below the permission nodes at x727 y550, leaving Delete report fully visible.", "cause": "The active Analyst role has Read permission.", "result": "The report card opens only when the token reaches its authorized operation.", "reading_seconds": 2, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "deny-delete", "start_seconds": 12, "end_seconds": 20, "heading": "No permission path", "lines": ["Delete report is denied."], "objects": ["Delete request token", "missing Analyst-to-Delete edge", "intact report"], "change": "A second request reaches Analyst then stops at a visible break before Delete; a deny badge appears and report stays intact.", "cause": "Analyst lacks Delete, and Maya cannot activate unassigned Administrator.", "result": "No effective permission path reaches Delete; denial is tied to the missing relationship.", "reading_seconds": 2, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "role-change", "start_seconds": 20, "end_seconds": 30, "heading": "Change the role assignment", "lines": ["Assign and activate Administrator.", "Delete is now permitted."], "objects": ["assignment edge", "Administrator session ring", "Delete token", "report card"], "change": "An explicit administrator action replaces Analyst assignment with Administrator; session ring moves; a new Delete request follows the now-valid path and removes the report card.", "cause": "The user\u2019s assignment and active role changed, not the report\u2019s identity.", "result": "One role change changes the operations available to the session.", "reading_seconds": 2.7, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Txt=({x,y,children,color=COLORS.textStrong,size=27}:{x:number;y:number;children:React.ReactNode;color?:string;size?:number})=><text x={x} y={y} textAnchor="middle" fill={color} fontSize={size}>{children}</text>;
const Box=({x,y,w=240,label,color=COLORS.primary}:{x:number;y:number;w?:number;label:string;color?:string})=><g><rect x={x-w/2} y={y-38} width={w} height={76} rx={14} fill={alpha(color,.12)} stroke={color} strokeWidth={3}/><Txt x={x} y={y+9} color={color}>{label}</Txt></g>;
export const stateAt=(t:number)=>({q:p(t,12.5,15),denied:t>=15&&t<20,roleShift:p(t,21,23),admin:t>=23,read:p(t,7,9),del:p(t,24,26),deleted:t>=26});
const Diagram:React.FC<{t:number}>=({t})=>{const s=stateAt(t);return <>
<Actor x={120} y={330} label="Maya" kind="person"/><Box x={435} y={240} label="Analyst"/><Box x={435} y={490} label="Administrator" w={275}/><Box x={825} y={240} label="Read report"/><Box x={825} y={490} label="Delete report"/>
<Channel x1={185} y1={320} x2={307} y2={250+240*s.roleShift} packet={t<12?s.read:t<20?s.q:s.del} progress={p(t,0.5,2)} color={COLORS.primary}/><Channel x1={560} y1={240} x2={700} y2={240} color={COLORS.result}/><Channel x1={580} y1={490} x2={700} y2={490} color={s.admin?COLORS.result:COLORS.textDim} packet={s.admin?s.del:undefined}/><path d="M560 475 L705 265" stroke={COLORS.textDim} strokeWidth={3}/>
{t>=6&&<g transform={`translate(0,${250*s.roleShift})`}><rect x={295} y={180} width={280} height={120} rx={22} stroke={COLORS.accent} fill="none" strokeWidth={3}/><Txt x={435} y={155} color={COLORS.accent}>Active role</Txt></g>}
{t>=12.5&&t<20&&<><path d="M440 290L555 388" stroke={COLORS.warn} strokeWidth={3} strokeDasharray="8 8"/><circle cx={440+115*s.q} cy={290+98*s.q} r={13} fill={COLORS.warn}/></>}
{s.denied&&<><Txt x={630} y={378} color={COLORS.warn}>No permission</Txt><Txt x={520} y={615} color={COLORS.warn}>DELETE DENIED</Txt></>}
{t>=7&&t<12&&<circle cx={560+140*s.read} cy={240} r={12} fill={COLORS.result}/>}
{t>=9&&t<12&&<><rect x={727} y={550} width={180} height={100} fill={alpha(COLORS.result,.12)} stroke={COLORS.result} strokeWidth={3}/>{[573,603,628].map(y=><path key={y} d={`M750 ${y}H880`} stroke={COLORS.result} strokeWidth={4}/>)}</>}
{t>=20&&<><Txt x={500} y={80} color={COLORS.accent}>{s.admin?'Administrator activated':'Assign Administrator'}</Txt>{s.admin&&<Txt x={500} y={615} color={COLORS.result}>{s.deleted?'Report deleted':'DELETE permission available'}</Txt>}{s.admin&&!s.deleted&&<rect x={770} y={555} width={110} height={115} rx={5} fill={alpha(COLORS.result,.13)} stroke={COLORS.result} strokeWidth={3}/>}</>}
</>};
const Scene:React.FC<{frame:number;index:number}>=({frame,index})=>{const scene=SCENE_PLAN[index];const t=frame/30+scene.start_seconds;return <LessonFrame topic={T.topic} heading={scene.heading} lines={scene.lines} takeaway={T.takeaway} frame={frame} step={index+1} steps={SCENE_PLAN.length}><Diagram t={t}/></LessonFrame>};
const Scene1:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={0}/>;
const Scene2:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={1}/>;
const Scene3:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={2}/>;
const Scene4:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={3}/>;
export const SCENES:SceneDef[] = [
  {id:'role-graph',Comp:Scene1,dur:180},
  {id:'activate',Comp:Scene2,dur:180},
  {id:'deny-delete',Comp:Scene3,dur:240},
  {id:'role-change',Comp:Scene4,dur:300},
];
export const Video=makeVideo(SCENES);
export default Video;
