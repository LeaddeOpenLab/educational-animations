import type { SceneDef } from '../Video';
import { SCENES as v0 } from './se01-authentication-and-authorization-boundary';
import { SCENES as v1 } from './se02-password-hashing-with-salt';
import { SCENES as v2 } from './se03-public-key-challenge-response-authentication';
import { SCENES as v3 } from './se04-oauth-20-authorization-code-flow';
import { SCENES as v4 } from './se05-openid-connect-id-token-validation';
import { SCENES as v5 } from './se06-webauthn-passkey-registration';
import { SCENES as v6 } from './se07-multi-factor-authentication-totp';
import { SCENES as v7 } from './se08-session-cookie-secure-attributes';
import { SCENES as v8 } from './se09-json-web-token-signature-verification';
import { SCENES as v9 } from './se10-refresh-token-rotation';
import { SCENES as v10 } from './se11-role-based-access-control';
import { SCENES as v11 } from './se12-attribute-based-access-control';
import { SCENES as v12 } from './se13-saml-service-provider-login-flow';
import { SCENES as v13 } from './se14-mutual-tls-certificate-authentication';
import { SCENES as v14 } from './se15-least-privilege-access-review';
export const VIDEOS = [
{id:"se01-authentication-and-authorization-boundary",title:"Authentication and Authorization Boundary",file:"se01_Authentication_and_Authorization_Boundary",scenes:v0,keyFrames:[90, 180, 330, 510, 630, 810]},
{id:"se02-password-hashing-with-salt",title:"Password Hashing with Salt",file:"se02_Password_Hashing_with_Salt",scenes:v1,keyFrames:[90, 240, 390, 540, 720, 840]},
{id:"se03-public-key-challenge-response-authentication",title:"Public-Key Challenge-Response Authentication",file:"se03_Public-Key_Challenge-Response_Authentication",scenes:v2,keyFrames:[90, 270, 420, 540, 720, 840]},
{id:"se04-oauth-20-authorization-code-flow",title:"OAuth 2.0 Authorization Code Flow",file:"se04_OAuth_20_Authorization_Code_Flow",scenes:v3,keyFrames:[90, 300, 480, 630, 750, 900]},
{id:"se05-openid-connect-id-token-validation",title:"OpenID Connect ID Token Validation",file:"se05_OpenID_Connect_ID_Token_Validation",scenes:v4,keyFrames:[90, 270, 450, 600, 750, 870]},
{id:"se06-webauthn-passkey-registration",title:"WebAuthn Passkey Registration",file:"se06_WebAuthn_Passkey_Registration",scenes:v5,keyFrames:[90, 270, 390, 510, 660, 840]},
{id:"se07-multi-factor-authentication-totp",title:"Multi-Factor Authentication TOTP",file:"se07_Multi-Factor_Authentication_TOTP",scenes:v6,keyFrames:[90, 240, 330, 510, 660, 870]},
{id:"se08-session-cookie-secure-attributes",title:"Session Cookie Secure Attributes",file:"se08_Session_Cookie_Secure_Attributes",scenes:v7,keyFrames:[90, 240, 390, 510, 690, 840]},
{id:"se09-json-web-token-signature-verification",title:"JSON Web Token Signature Verification",file:"se09_JSON_Web_Token_Signature_Verification",scenes:v8,keyFrames:[90, 270, 390, 540, 660, 840]},
{id:"se10-refresh-token-rotation",title:"Refresh Token Rotation",file:"se10_Refresh_Token_Rotation",scenes:v9,keyFrames:[90, 210, 360, 540, 720, 870]},
{id:"se11-role-based-access-control",title:"Role-Based Access Control",file:"se11_Role-Based_Access_Control",scenes:v10,keyFrames:[90, 270, 420, 480, 705, 825]},
{id:"se12-attribute-based-access-control",title:"Attribute-Based Access Control",file:"se12_Attribute-Based_Access_Control",scenes:v11,keyFrames:[120, 300, 495, 600, 750, 840]},
{id:"se13-saml-service-provider-login-flow",title:"SAML Service Provider Login Flow",file:"se13_SAML_Service_Provider_Login_Flow",scenes:v12,keyFrames:[105, 270, 465, 570, 750, 855]},
{id:"se14-mutual-tls-certificate-authentication",title:"Mutual TLS Certificate Authentication",file:"se14_Mutual_TLS_Certificate_Authentication",scenes:v13,keyFrames:[105, 315, 495, 600, 765, 870]},
{id:"se15-least-privilege-access-review",title:"Least-Privilege Access Review",file:"se15_Least-Privilege_Access_Review",scenes:v14,keyFrames:[120, 330, 510, 600, 750, 840]},
];