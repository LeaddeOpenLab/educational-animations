import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {COLORS,alpha} from '../theme';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Credential,Channel,KeyMark,CheckRow} from '../components/Security';
const T = {"topic": "Least-Privilege Access Review", "takeaway": "An access review preserves necessary privileges and removes excess access based on current duties."};
const DESIGN_AUDIT = {
  visualArgument: 'An entitlement fan shrinks from three live branches to one, then two requests prove the effective result.',
  motion: 'Review marks each entitlement; excess edges retract; successful and denied tests validate the change.',
  example: 'An employee moved to report-reading duties but retains legacy export and administration access.',
  antiTemplate: 'This is a time-based review-and-removal process, not initial RBAC assignment or runtime ABAC evaluation.',
  sceneRationale: 'inventory: Access accumulated earlier may exceed what the current job needs. All granted rights are visible before the review makes any change. review: The reviewer judges the business need rather than inferring necessity solely from recent use. One permission remains justified and two are excess. revoke: The approved review findings are applied to actual permission assignments. The effective privilege set now contains only Read reports. verify: Post-change checks confirm retained work still succeeds and revoked access no longer does. Least privilege is demonstrated by both successful necessary work and denied excess work.'
};
const SCENE_PLAN = [{"id": "inventory", "start_seconds": 0, "end_seconds": 7, "heading": "Compare access with current work", "lines": ["Current duty: read monthly reports", "Granted: read, export and administer"], "objects": ["employee badge (150,350)", "three entitlement branches at y200/350/500", "current duty card (500,90)"], "change": "Three existing access edges draw from employee to Read reports, Export all data, Admin settings; duty card drops beside the graph.", "cause": "Access accumulated earlier may exceed what the current job needs.", "result": "All granted rights are visible before the review makes any change.", "reading_seconds": 3.3, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "review", "start_seconds": 7, "end_seconds": 15, "heading": "Validate each privilege", "lines": ["Keep access required for the duty.", "Flag access without a current need."], "objects": ["review cursor", "three entitlement cards", "review owner badge"], "change": "A reviewer cursor compares each card to the duty: Read gains Keep; Export and Admin gain Remove, with explicit no-current-need tags.", "cause": "The reviewer judges the business need rather than inferring necessity solely from recent use.", "result": "One permission remains justified and two are excess.", "reading_seconds": 4.0, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "revoke", "start_seconds": 15, "end_seconds": 23, "heading": "Remove excess privileges", "lines": ["Revoke export and administration.", "Retain report reading."], "objects": ["export edge", "admin edge", "read edge", "removed access tray"], "change": "Export and Admin edges retract from their targets; their cards move to a Removed tray; Read edge stays continuous.", "cause": "The approved review findings are applied to actual permission assignments.", "result": "The effective privilege set now contains only Read reports.", "reading_seconds": 2.3, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}, {"id": "verify", "start_seconds": 23, "end_seconds": 30, "heading": "Verify the new access", "lines": ["Read succeeds; export is denied.", "Record the decision for the next review."], "objects": ["Read test token", "Export test token", "review log card"], "change": "Read token follows retained edge and opens a report; Export token stops at revoked connection; review log stamps the changed permissions and date.", "cause": "Post-change checks confirm retained work still succeeds and revoked access no longer does.", "result": "Least privilege is demonstrated by both successful necessary work and denied excess work.", "reading_seconds": 4.0, "timing_reason": "Reserve the first 2\u20133 seconds for the causal visual action and the remaining time for reading the settled result."}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Txt=({x,y,children,color=COLORS.textStrong,size=27}:{x:number;y:number;children:React.ReactNode;color?:string;size?:number})=><text x={x} y={y} textAnchor="middle" fill={color} fontSize={size}>{children}</text>;
const Box=({x,y,w=240,label,color=COLORS.primary}:{x:number;y:number;w?:number;label:string;color?:string})=><g><rect x={x-w/2} y={y-38} width={w} height={76} rx={14} fill={alpha(color,.12)} stroke={color} strokeWidth={3}/><Txt x={x} y={y+9} color={color}>{label}</Txt></g>;
export const stateAt=(t:number)=>({remove:p(t,16,20),revoked:t>=20,review:Math.floor((t-8)/2),test:p(t,24,26)});
const Diagram:React.FC<{t:number}>=({t})=>{const s=stateAt(t);return <>
<Actor x={120} y={330} label="Report reader" kind="person"/><Box x={500} y={90} label="Duty: read monthly reports" w={470}/>
{['Read reports','Export all data','Admin settings'].map((n,i)=>{const y=230+i*145;const removed=i>0;const k=removed?s.remove:0;return <g key={n}><Channel x1={190} y1={330} x2={600-(410*k)} y2={y+(330-y)*k} color={t<8?COLORS.primary:removed?COLORS.warn:COLORS.result} progress={t<4?p(t,1+i*.4,3+i*.4):1-k}/><g transform={`translate(${k*85},${k*40})`} opacity={1-k*.55}><Box x={770} y={y} label={n} w={290} color={removed?COLORS.warn:COLORS.result}/></g>{t>=8&&t<15&&s.review===i&&<rect x={603} y={y-56} width={334} height={112} rx={18} fill="none" stroke={COLORS.accent} strokeWidth={5}/>}
{removed&&t>=10+i&&t<15&&<Txt x={455} y={y+48} color={COLORS.warn}>No current need</Txt>}
{removed&&s.revoked&&<Txt x={440} y={y} color={COLORS.warn}>REVOKED</Txt>}{!removed&&t>=8&&<Txt x={460} y={200} color={COLORS.result}>KEEP</Txt>}</g>})}
{t>=23&&<><circle cx={190+410*s.test} cy={330-100*s.test} r={12} fill={COLORS.result}/><circle cx={190+120*s.test} cy={330+45*s.test} r={12} fill={COLORS.warn}/>{s.test===1&&<><Txt x={500} y={260} color={COLORS.result}>Read succeeds</Txt><Txt x={380} y={415} color={COLORS.warn}>Export denied</Txt></>}</>}
<Txt x={500} y={650} color={COLORS.result}>Necessary access remains connected</Txt>
</>};
const Scene:React.FC<{frame:number;index:number}>=({frame,index})=>{const scene=SCENE_PLAN[index];const t=frame/30+scene.start_seconds;return <LessonFrame topic={T.topic} heading={scene.heading} lines={scene.lines} takeaway={T.takeaway} frame={frame} step={index+1} steps={SCENE_PLAN.length}><Diagram t={t}/></LessonFrame>};
const Scene1:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={0}/>;
const Scene2:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={1}/>;
const Scene3:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={2}/>;
const Scene4:React.FC<{frame:number}>=({frame})=><Scene frame={frame} index={3}/>;
export const SCENES:SceneDef[] = [
  {id:'inventory',Comp:Scene1,dur:210},
  {id:'review',Comp:Scene2,dur:240},
  {id:'revoke',Comp:Scene3,dur:240},
  {id:'verify',Comp:Scene4,dur:210},
];
export const Video=makeVideo(SCENES);
export default Video;
