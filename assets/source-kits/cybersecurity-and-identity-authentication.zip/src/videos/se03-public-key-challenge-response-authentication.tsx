import React from 'react';
import {makeVideo, type SceneDef} from '../Video';
import {LessonFrame} from '../components/LessonFrame';
import {Actor,Gate,KeyMark,CheckRow} from '../components/Security';
import {COLORS as C,alpha} from '../theme';
const T = {"topic": "Public-Key Challenge-Response Authentication", "takeaway": "A fresh challenge is signed with the private key and verified with the registered public key."};
const DESIGN_AUDIT = {
  visualArgument: 'A fixed private key creates a traveling proof that fits only the server’s current challenge.',
  motion: 'Challenge travels outward, signature returns, old proof is blocked.',
  example: 'Schematic challenge labels C42 and C17 stand for random challenge bytes.',
  antiTemplate: 'A round trip around an immovable key vault with a stale-proof comparison.',
  sceneRationale: 'Locate secrets, initiate challenge, show signing, show fresh-proof validation.'
};
const SCENE_PLAN = [{"id": "keys", "start_seconds": 0, "end_seconds": 6, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "The private key stays here", "objects": ["authenticator vault", "private key", "server public key", "challenge slot"], "change": "Private key locks inside device vault while matching public key is visible at server.", "cause": "The verifier already holds the registered public key.", "result": "The two parties hold different key material.", "lines": ["Private key: device", "Public key: server"]}, {"id": "challenge", "start_seconds": 6, "end_seconds": 13, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Send a fresh challenge", "objects": ["server random challenge C42", "device vault", "challenge route"], "change": "Challenge C42 moves from server to device and is inserted into signing area beside the fixed private key.", "cause": "The server creates a fresh unpredictable challenge for this attempt.", "result": "The device receives the data to prove possession.", "lines": ["Fresh challenge: C42", "Short label represents random bytes."]}, {"id": "sign", "start_seconds": 13, "end_seconds": 21, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Return a signature", "objects": ["challenge C42", "signing enclosure", "signature S42", "fixed private key"], "change": "A signature tile grows from signing operation and returns to server; the private key never crosses the enclosure.", "cause": "The private key signs challenge-bound data.", "result": "The server receives proof without receiving the private key.", "lines": ["Sign challenge-bound data.", "Return the signature."]}, {"id": "verify", "start_seconds": 21, "end_seconds": 30, "reading_seconds": 4, "timing_reason": "Allow the causal movement to finish, then leave readable labels visible for comparison.", "heading": "Verify this attempt", "objects": ["C42 challenge", "S42 signature", "registered public key", "old C17 signature"], "change": "Current signature docks with C42 and public key and earns a check; faded old C17 signature approaches and is rejected by the current-challenge slot.", "cause": "The server verifies both the signature and the expected fresh challenge.", "result": "A proof for an old challenge cannot be replayed for this attempt.", "lines": ["Verify signature + expected challenge"]}];

const p=(t:number,a:number,b:number)=>Math.max(0,Math.min(1,(t-a)/(b-a)));
const Label=({x,y,text,color=C.textStrong,size=28}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} textAnchor="middle">{text}</text>;
const Box=({x,y,w=240,h=80,text,color=C.primary}:{x:number;y:number;w?:number;h?:number;text:string;color?:string})=><g><rect x={x} y={y} width={w} height={h} rx={14} fill={C.bg1} stroke={color} strokeWidth={3}/><Label x={x+w/2} y={y+h/2+10} text={text} color={color}/></g>;
const Line=({x1,y1,x2,y2,color=C.primary}:{x1:number;y1:number;x2:number;y2:number;color?:string})=><path d={`M${x1} ${y1}L${x2} ${y2}`} stroke={color} strokeWidth={3} fill="none"/>;

export const deriveState=(t:number)=>({challenge:p(t,7,11),signature:p(t,14,19),valid:t>=24,replay:p(t,26,28)});
function Diagram({t}:{t:number}){const s=deriveState(t);return <>
<rect x={40} y={140} width={280} height={370} rx={24} fill={alpha(C.primary,.08)} stroke={C.primary} strokeWidth={3}/><Label x={180} y={110} text="Device vault"/><KeyMark x={175} y={370} label="Private key"/><Actor x={810} y={315} label="Server"/><KeyMark x={810} y={540} label="Public key" color={C.result}/>
{t>=6&&<><Line x1={730} y1={210} x2={270} y2={210}/><Box x={670-550*s.challenge} y={180} w={150} h={65} text="C42"/>{t>=13&&<Label x={180} y={290} text="SIGN" color={C.accent}/>}</>}
{t>=13&&<><Line x1={320} y1={440} x2={710} y2={440} color={C.accent}/><Box x={270+370*s.signature} y={405} w={190} h={65} text="Signature" color={C.accent}/></>}
{s.valid&&<CheckRow x={540} y={100} label="C42 + signature valid" status="pass"/>}
{t>=26&&<><Box x={390+70*s.replay} y={590} w={260} h={65} text="Old proof: C17" color={C.warn}/><path d="M750 580V680" stroke={C.warn} strokeWidth={7}/><Label x={825} y={655} text="Reject" color={C.warn}/></>}
</>}


const Keys: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'The private key stays here'} lines={["Private key: device", "Public key: server"]} takeaway={T.takeaway} frame={frame} step={1} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={0+frame/30}/></g>
  </LessonFrame>
);

const Challenge: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Send a fresh challenge'} lines={["Fresh challenge: C42", "Short label represents random bytes."]} takeaway={T.takeaway} frame={frame} step={2} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={6+frame/30}/></g>
  </LessonFrame>
);

const Sign: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Return a signature'} lines={["Sign challenge-bound data.", "Return the signature."]} takeaway={T.takeaway} frame={frame} step={3} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={13+frame/30}/></g>
  </LessonFrame>
);

const Verify: React.FC<{frame:number}> = ({frame}) => (
  <LessonFrame topic={T.topic} heading={'Verify this attempt'} lines={["Verify signature + expected challenge"]} takeaway={T.takeaway} frame={frame} step={4} steps={4}>
    <g className="g1-stage"><style>{`.g1-stage text { font-size: 26px; }`}</style><Diagram t={21+frame/30}/></g>
  </LessonFrame>
);

export const SCENES: SceneDef[] = [
  {id:'keys',Comp:Keys,dur:180},
  {id:'challenge',Comp:Challenge,dur:210},
  {id:'sign',Comp:Sign,dur:240},
  {id:'verify',Comp:Verify,dur:270}
];
export default makeVideo(SCENES);
